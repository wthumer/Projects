<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Appointment Management";
$actionButtons = '<a href="add_appointment.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Add Appointment
                 </a>';
?>

<?php
// Display success/error messages
if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            ' . $_SESSION['success'] . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
    unset($_SESSION['success']);
}

if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            ' . $_SESSION['error'] . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
    unset($_SESSION['error']);
}
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-calendar-check me-2"></i>Appointment List</h3>
        <?php echo $actionButtons; ?>
    </div>
    <div class="card-body">
        <!-- Search Form -->
        <div class="mb-3">
            <form action="search_appointment.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by patient name, doctor name or date..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_appointments.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT a.*, p.Name AS PatientName, s.Name AS DoctorName 
                            FROM Appointment a
                            JOIN Patient p ON a.PatientID = p.PatientID
                            JOIN Staff s ON a.DoctorID = s.StaffID
                            ORDER BY a.Date DESC, a.Time DESC";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['AppointmentID']}</td>
                                <td>{$row['PatientName']}</td>
                                <td>Dr. {$row['DoctorName']}</td>
                                <td>{$row['Date']}</td>
                                <td>{$row['Time']}</td>
                                <td>{$row['Reason']}</td>
                                <td><span class='badge bg-" . getStatusColor($row['Status']) . "'>{$row['Status']}</span></td>
                                <td>
                                    <a href='edit_appointment.php?id={$row['AppointmentID']}' class='btn btn-sm btn-warning'>
                                        <i class='fas fa-edit'></i>
                                    </a>
                                    <a href='delete_appointment.php?id={$row['AppointmentID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this appointment?\")'>
                                        <i class='fas fa-trash'></i>
                                    </a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>No appointments found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
function getStatusColor($status) {
    switch($status) {
        case 'Scheduled': return 'primary';
        case 'Completed': return 'success';
        case 'Cancelled': return 'danger';
        case 'No-show': return 'warning';
        default: return 'secondary';
    }
}
?>

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this appointment?");
}
</script>

<?php require_once '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
session_start();

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Appointment ID is required for deletion.";
    header("Location: view_appointments.php");
    exit();
}

$appointmentID = (int)$_GET['id'];

// Check if appointment exists
$sql = "SELECT * FROM Appointment WHERE AppointmentID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $appointmentID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Appointment not found.";
    header("Location: view_appointments.php");
    exit();
}

// Delete the appointment
$deleteSql = "DELETE FROM Appointment WHERE AppointmentID = ?";
$deleteStmt = $conn->prepare($deleteSql);
$deleteStmt->bind_param("i", $appointmentID);

if ($deleteStmt->execute()) {
    $_SESSION['success'] = "Appointment deleted successfully.";
} else {
    $_SESSION['error'] = "Error deleting appointment: " . $conn->error;
}

$deleteStmt->close();
$stmt->close();
header("Location: view_appointments.php");
exit();
?>
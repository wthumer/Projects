<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Check if appointment ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Appointment ID not provided";
    header("Location: view_appointments.php");
    exit();
}

$appointmentId = intval($_GET['id']);

// Fetch appointment data
$sql = "SELECT * FROM Appointment WHERE AppointmentID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $appointmentId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Appointment not found";
    header("Location: view_appointments.php");
    exit();
}

$appointment = $result->fetch_assoc();

$pageTitle = "Edit Appointment";
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-calendar-edit me-2"></i>Edit Appointment</h3>
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form id="appointmentForm" action="update_appointment.php" method="post" class="needs-validation" novalidate>
            <input type="hidden" name="appointment_id" value="<?php echo $appointmentId; ?>">
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="patient" class="form-label">Patient *</label>
                    <select class="form-select" id="patient" name="patient" required>
                        <option value="">-- Select Patient --</option>
                        <?php
                        $patients = $conn->query("SELECT * FROM Patient ORDER BY Name");
                        while($patient = $patients->fetch_assoc()):
                        ?>
                            <option value="<?= $patient['PatientID'] ?>" <?= $appointment['PatientID'] == $patient['PatientID'] ? 'selected' : '' ?>>
                                <?= $patient['Name'] ?> (ID: <?= $patient['PatientID'] ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                    <div class="invalid-feedback">Please select a patient</div>
                </div>
                <div class="col-md-6">
                    <label for="doctor" class="form-label">Doctor *</label>
                    <select class="form-select" id="doctor" name="doctor" required>
                        <option value="">-- Select Doctor --</option>
                        <?php
                        $doctors = $conn->query("SELECT * FROM Staff WHERE Role = 'Doctor' ORDER BY Name");
                        while($doctor = $doctors->fetch_assoc()):
                        ?>
                            <option value="<?= $doctor['StaffID'] ?>" <?= $appointment['DoctorID'] == $doctor['StaffID'] ? 'selected' : '' ?>>
                                Dr. <?= $doctor['Name'] ?> (<?= $doctor['Specialization'] ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                    <div class="invalid-feedback">Please select a doctor</div>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="date" class="form-label">Date *</label>
                    <input type="date" class="form-control" id="date" name="date" required
                           value="<?php echo htmlspecialchars($appointment['Date']); ?>">
                    <div class="invalid-feedback">Please select a date</div>
                </div>
                <div class="col-md-6">
                    <label for="time" class="form-label">Time *</label>
                    <input type="time" class="form-control" id="time" name="time" required
                           value="<?php echo htmlspecialchars($appointment['Time']); ?>">
                    <div class="invalid-feedback">Please select a time</div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="reason" class="form-label">Reason *</label>
                <textarea class="form-control" id="reason" name="reason" rows="3" required><?php 
                    echo htmlspecialchars($appointment['Reason']); 
                ?></textarea>
                <div class="invalid-feedback">Please enter appointment reason</div>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Status *</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="Scheduled" <?= $appointment['Status'] == 'Scheduled' ? 'selected' : '' ?>>Scheduled</option>
                    <option value="Completed" <?= $appointment['Status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                    <option value="Cancelled" <?= $appointment['Status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    <option value="No-show" <?= $appointment['Status'] == 'No-show' ? 'selected' : '' ?>>No-show</option>
                </select>
                <div class="invalid-feedback">Please select status</div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_appointments.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Update Appointment
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
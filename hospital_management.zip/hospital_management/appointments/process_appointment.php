<?php
require_once '../includes/config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['patient', 'doctor', 'date', 'time', 'reason', 'status'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: add_appointment.php");
            exit();
        }
    }

    // Sanitize inputs
    $patient = intval($_POST['patient']);
    $doctor = intval($_POST['doctor']);
    $date = $conn->real_escape_string($_POST['date']);
    $time = $conn->real_escape_string($_POST['time']);
    $reason = $conn->real_escape_string($_POST['reason']);
    $status = $conn->real_escape_string($_POST['status']);

    // Check if patient exists
    $checkPatient = "SELECT PatientID FROM Patient WHERE PatientID = ?";
    $stmt = $conn->prepare($checkPatient);
    $stmt->bind_param("i", $patient);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $_SESSION['error'] = "Selected patient does not exist";
        header("Location: add_appointment.php");
        exit();
    }

    // Check if doctor exists
    $checkDoctor = "SELECT StaffID FROM Staff WHERE StaffID = ? AND Role = 'Doctor'";
    $stmt = $conn->prepare($checkDoctor);
    $stmt->bind_param("i", $doctor);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $_SESSION['error'] = "Selected doctor does not exist";
        header("Location: add_appointment.php");
        exit();
    }

    // Check for scheduling conflicts
    $checkConflict = "SELECT AppointmentID FROM Appointment 
                     WHERE DoctorID = ? AND Date = ? AND Time = ? AND Status != 'Cancelled'";
    $stmt = $conn->prepare($checkConflict);
    $stmt->bind_param("iss", $doctor, $date, $time);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "The doctor already has an appointment at this time";
        header("Location: add_appointment.php");
        exit();
    }

    // Insert new appointment
    $sql = "INSERT INTO Appointment (PatientID, DoctorID, Date, Time, Reason, Status) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iissss", $patient, $doctor, $date, $time, $reason, $status);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Appointment added successfully!";
        header("Location: view_appointments.php");
        exit();
    } else {
        $_SESSION['error'] = "Error adding appointment: " . $conn->error;
        header("Location: add_appointment.php");
        exit();
    }
}

// If not POST request, redirect
header("Location: add_appointment.php");
exit();
?>


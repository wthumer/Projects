<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient = intval($_POST['patient']);
    $doctor = intval($_POST['doctor']);
    $date = $conn->real_escape_string($_POST['date']);
    $time = $conn->real_escape_string($_POST['time']);
    $reason = $conn->real_escape_string($_POST['reason']);

    $sql = "INSERT INTO Appointment (PatientID, DoctorID, Date, Time, Reason, Status) 
            VALUES ($patient, $doctor, '$date', '$time', '$reason', 'Scheduled')";

    if ($conn->query($sql) === TRUE) {
        header("Location: view_appointments.php?success=1");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
<?php
require_once '../includes/config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['appointment_id', 'patient', 'doctor', 'date', 'time', 'reason', 'status'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: edit_appointment.php?id=" . $_POST['appointment_id']);
            exit();
        }
    }

    // Sanitize inputs
    $appointmentId = intval($_POST['appointment_id']);
    $patient = intval($_POST['patient']);
    $doctor = intval($_POST['doctor']);
    $date = $conn->real_escape_string($_POST['date']);
    $time = $conn->real_escape_string($_POST['time']);
    $reason = $conn->real_escape_string($_POST['reason']);
    $status = $conn->real_escape_string($_POST['status']);

    // Check if appointment exists
    $checkAppointment = "SELECT AppointmentID FROM Appointment WHERE AppointmentID = ?";
    $stmt = $conn->prepare($checkAppointment);
    $stmt->bind_param("i", $appointmentId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $_SESSION['error'] = "Appointment not found";
        header("Location: view_appointments.php");
        exit();
    }

    // Check if patient exists
    $checkPatient = "SELECT PatientID FROM Patient WHERE PatientID = ?";
    $stmt = $conn->prepare($checkPatient);
    $stmt->bind_param("i", $patient);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $_SESSION['error'] = "Selected patient does not exist";
        header("Location: edit_appointment.php?id=" . $appointmentId);
        exit();
    }

    // Check if doctor exists
    $checkDoctor = "SELECT StaffID FROM Staff WHERE StaffID = ? AND Role = 'Doctor'";
    $stmt = $conn->prepare($checkDoctor);
    $stmt->bind_param("i", $doctor);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $_SESSION['error'] = "Selected doctor does not exist";
        header("Location: edit_appointment.php?id=" . $appointmentId);
        exit();
    }

    // Check for scheduling conflicts (excluding current appointment)
    $checkConflict = "SELECT AppointmentID FROM Appointment 
                     WHERE DoctorID = ? AND Date = ? AND Time = ? 
                     AND Status != 'Cancelled' AND AppointmentID != ?";
    $stmt = $conn->prepare($checkConflict);
    $stmt->bind_param("issi", $doctor, $date, $time, $appointmentId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "The doctor already has an appointment at this time";
        header("Location: edit_appointment.php?id=" . $appointmentId);
        exit();
    }

    // Update appointment
    $sql = "UPDATE Appointment SET 
            PatientID = ?, 
            DoctorID = ?, 
            Date = ?, 
            Time = ?, 
            Reason = ?, 
            Status = ? 
            WHERE AppointmentID = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iissssi", $patient, $doctor, $date, $time, $reason, $status, $appointmentId);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Appointment updated successfully!";
        header("Location: view_appointments.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating appointment: " . $stmt->error;
        header("Location: edit_appointment.php?id=" . $appointmentId);
        exit();
    }
}

// If not POST request, redirect
header("Location: view_appointments.php");
exit();
?>
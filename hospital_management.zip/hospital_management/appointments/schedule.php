    <?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Get patients and doctors for dropdowns
$patients = $conn->query("SELECT * FROM Patient");
$doctors = $conn->query("SELECT * FROM Staff WHERE Role = 'Doctor'");
?>

<h2>Schedule New Appointment</h2>
<form action="process_appointment.php" method="post">
    <div>
        <label for="patient">Patient:</label>
        <select id="patient" name="patient" required>
            <option value="">-- Select Patient --</option>
            <?php while($patient = $patients->fetch_assoc()): ?>
                <option value="<?= $patient['PatientID'] ?>"><?= $patient['Name'] ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div>
        <label for="doctor">Doctor:</label>
        <select id="doctor" name="doctor" required>
            <option value="">-- Select Doctor --</option>
            <?php while($doctor = $doctors->fetch_assoc()): ?>
                <option value="<?= $doctor['StaffID'] ?>"><?= $doctor['Name'] ?> (<?= $doctor['Specialization'] ?>)</option>
            <?php endwhile; ?>
        </select>
    </div>
    <div>
        <label for="date">Date:</label>
        <input type="date" id="date" name="date" required>
    </div>
    <div>
        <label for="time">Time:</label>
        <input type="time" id="time" name="time" required>
    </div>
    <div>
        <label for="reason">Reason:</label>
        <textarea id="reason" name="reason" required></textarea>
    </div>
    <button type="submit">Schedule Appointment</button>
</form>

<?php require_once '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Appointment Search Results";
$actionButtons = '<a href="add_appointment.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Add Appointment
                 </a>';

// Get search term
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';

?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-search me-2"></i>Appointment Search Results</h3>
        <?php echo $actionButtons; ?>
    </div>
    <div class="card-body">
        <!-- Search Form -->
        <div class="mb-3">
            <form action="search_appointment.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by patient name, doctor name or date..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_appointments.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($searchTerm)) {
                        // Prepare SQL to search by patient name, doctor name, or date
                        $sql = "SELECT a.*, p.Name AS PatientName, s.Name AS DoctorName 
                                FROM Appointment a
                                JOIN Patient p ON a.PatientID = p.PatientID
                                JOIN Staff s ON a.DoctorID = s.StaffID
                                WHERE p.Name LIKE ? OR 
                                      s.Name LIKE ? OR 
                                      a.Date LIKE ? OR
                                      a.AppointmentID = ?
                                ORDER BY a.Date DESC, a.Time DESC";
                        
                        $stmt = $conn->prepare($sql);
                        
                        // For AppointmentID, try exact match if search term is numeric
                        if (is_numeric($searchTerm)) {
                            $appointmentID = (int)$searchTerm;
                            $nameSearch = "%{$searchTerm}%";
                            $dateSearch = "%{$searchTerm}%";
                            $stmt->bind_param("sssi", $nameSearch, $nameSearch, $dateSearch, $appointmentID);
                        } else {
                            $nameSearch = "%{$searchTerm}%";
                            $dateSearch = "%{$searchTerm}%";
                            $appointmentID = 0; // Will never match since AppointmentID is positive
                            $stmt->bind_param("sssi", $nameSearch, $nameSearch, $dateSearch, $appointmentID);
                        }
                        
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['AppointmentID']}</td>
                                    <td>{$row['PatientName']}</td>
                                    <td>Dr. {$row['DoctorName']}</td>
                                    <td>{$row['Date']}</td>
                                    <td>{$row['Time']}</td>
                                    <td>{$row['Reason']}</td>
                                    <td><span class='badge bg-" . getStatusColor($row['Status']) . "'>{$row['Status']}</span></td>
                                    <td>
                                        <a href='edit_appointment.php?id={$row['AppointmentID']}' class='btn btn-sm btn-warning'>
                                            <i class='fas fa-edit'></i>
                                        </a>
                                        <a href='delete_appointment.php?id={$row['AppointmentID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this appointment?\")'>
                                            <i class='fas fa-trash'></i>
                                        </a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8' class='text-center'>No appointments found matching your search criteria</td></tr>";
                        }
                        
                        $stmt->close();
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>Please enter a patient name, doctor name, or date to search</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
function getStatusColor($status) {
    switch($status) {
        case 'Scheduled': return 'primary';
        case 'Completed': return 'success';
        case 'Cancelled': return 'danger';
        case 'No-show': return 'warning';
        default: return 'secondary';
    }
}
?>

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this appointment?");
}
</script>

<?php require_once '../includes/footer.php'; ?>
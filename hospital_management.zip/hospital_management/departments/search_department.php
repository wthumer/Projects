<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Search Departments";
$searchTerm = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';

$actionButtons = '<a href="add_department.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Add Department
                 </a>';
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-building me-2"></i>Search Results</h3>
        <?php echo $actionButtons; ?>
    </div>
    <div class="card-body">
        <div class="mb-3">
            <form action="search_department.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by department name or HOD..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_departments.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Head of Department</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM Department 
                            WHERE Name LIKE '%$searchTerm%' 
                            OR HOD LIKE '%$searchTerm%' 
                            OR Description LIKE '%$searchTerm%'";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['DepartmentID']}</td>
                                <td>{$row['Name']}</td>
                                <td>{$row['HOD']}</td>
                                <td>" . substr($row['Description'], 0, 50) . (strlen($row['Description']) > 50 ? '...' : '') . "</td>
                                <td>
                                    <a href='edit_department.php?id={$row['DepartmentID']}' class='btn btn-sm btn-warning'>
                                        <i class='fas fa-edit'></i>
                                    </a>
                                    <a href='delete_department.php?id={$row['DepartmentID']}' class='btn btn-sm btn-danger' onclick='return confirmDelete()'>
                                        <i class='fas fa-trash'></i>
                                    </a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>No departments found matching your search</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this department?");
}
</script>

<?php require_once '../includes/footer.php'; ?>
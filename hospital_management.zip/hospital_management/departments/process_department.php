<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Basic validation
    if (empty($_POST['name'])) {
        $_SESSION['error'] = "Department name is required";
        header("Location: " . (isset($_POST['department_id']) ? 'edit_department.php?id='.$_POST['department_id'] : 'add_department.php'));
        exit();
    }

    $name = sanitizeInput($_POST['name']);
    $description = sanitizeInput($_POST['description'] ?? '');
    $hod = sanitizeInput($_POST['hod'] ?? '');

    try {
        if (isset($_POST['department_id']) && is_numeric($_POST['department_id'])) {
            // Update existing department
            $departmentId = intval($_POST['department_id']);
            $sql = "UPDATE Department SET 
                    Name = ?, 
                    Description = ?, 
                    HOD = ? 
                    WHERE DepartmentID = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $name, $description, $hod, $departmentId);
            
            if ($stmt->execute()) {
                $_SESSION['success'] = "Department updated successfully";
            } else {
                throw new Exception("Error updating department: " . $stmt->error);
            }
        } else {
            // Add new department
            $sql = "INSERT INTO Department (Name, Description, HOD) VALUES (?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $name, $description, $hod);
            
            if ($stmt->execute()) {
                $_SESSION['success'] = "Department added successfully";
            } else {
                throw new Exception("Error adding department: " . $stmt->error);
            }
        }
        
        header("Location: view_departments.php");
        exit();
        
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: " . (isset($_POST['department_id']) ? 'edit_department.php?id='.$_POST['department_id'] : 'add_department.php'));
        exit();
    }
} else {
    $_SESSION['error'] = "Invalid request method";
    header("Location: view_departments.php");
    exit();
}
?>
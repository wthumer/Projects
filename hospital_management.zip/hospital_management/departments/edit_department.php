<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Edit Department";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "Invalid department ID";
    header("Location: view_departments.php");
    exit();
}

$departmentId = $_GET['id'];
$sql = "SELECT * FROM Department WHERE DepartmentID = $departmentId";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $_SESSION['error'] = "Department not found";
    header("Location: view_departments.php");
    exit();
}

$department = $result->fetch_assoc();
?>

<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-building me-2"></i>Edit Department</h4>
        </div>
        <div class="card-body">
            <form action="process_department.php" method="post" id="departmentForm">
                <input type="hidden" name="department_id" value="<?php echo $department['DepartmentID']; ?>">
                <div class="mb-3">
                    <label for="name" class="form-label">Department Name</label>
                    <input type="text" class="form-control" id="name" name="name" required value="<?php echo htmlspecialchars($department['Name']); ?>">
                </div>
                <div class="mb-3">
                    <label for="hod" class="form-label">Head of Department</label>
                    <input type="text" class="form-control" id="hod" name="hod" value="<?php echo htmlspecialchars($department['HOD']); ?>">
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($department['Description']); ?></textarea>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Update Department
                    </button>
                    <a href="view_departments.php" class="btn btn-secondary">
                        <i class="fas fa-times me-1"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
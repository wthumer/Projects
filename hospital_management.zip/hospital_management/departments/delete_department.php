<?php
require_once '../includes/config.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $departmentId = intval($_GET['id']);
    
    // Check if department exists
    $checkSql = "SELECT * FROM Department WHERE DepartmentID = $departmentId";
    $checkResult = $conn->query($checkSql);
    
    if ($checkResult->num_rows == 0) {
        $_SESSION['error'] = "Department not found";
        header("Location: view_departments.php");
        exit();
    }
    
    // Delete department
    $sql = "DELETE FROM Department WHERE DepartmentID = $departmentId";
    
    if ($conn->query($sql)) {
        $_SESSION['success'] = "Department deleted successfully";
    } else {
        $_SESSION['error'] = "Error deleting department: " . $conn->error;
    }
} else {
    $_SESSION['error'] = "Invalid department ID";
}

header("Location: view_departments.php");
exit();
?>
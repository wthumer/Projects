<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Add New Room";
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-plus-circle me-2"></i>Add New Room</h3>
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form id="roomForm" action="process_room.php" method="post" class="needs-validation" novalidate>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="type" class="form-label">Room Type *</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="">Select Type</option>
                        <option value="ICU" <?php echo (isset($_POST['type']) && $_POST['type'] == 'ICU') ? 'selected' : ''; ?>>ICU</option>
                        <option value="General" <?php echo (isset($_POST['type']) && $_POST['type'] == 'General') ? 'selected' : ''; ?>>General</option>
                        <option value="Private" <?php echo (isset($_POST['type']) && $_POST['type'] == 'Private') ? 'selected' : ''; ?>>Private</option>
                    </select>
                    <div class="invalid-feedback">Please select room type</div>
                </div>
                <div class="col-md-3">
                    <label for="capacity" class="form-label">Capacity *</label>
                    <input type="number" class="form-control" id="capacity" name="capacity" min="1" max="10" required
                           value="<?php echo isset($_POST['capacity']) ? htmlspecialchars($_POST['capacity']) : ''; ?>">
                    <div class="invalid-feedback">Please enter a valid capacity (1-10)</div>
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status *</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="">Select Status</option>
                        <option value="Available" <?php echo (isset($_POST['status']) && $_POST['status'] == 'Available') ? 'selected' : ''; ?>>Available</option>
                        <option value="Occupied" <?php echo (isset($_POST['status']) && $_POST['status'] == 'Occupied') ? 'selected' : ''; ?>>Occupied</option>
                        <option value="Maintenance" <?php echo (isset($_POST['status']) && $_POST['status'] == 'Maintenance') ? 'selected' : ''; ?>>Maintenance</option>
                    </select>
                    <div class="invalid-feedback">Please select status</div>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_rooms.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Room
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['type', 'capacity', 'status'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: add_room.php");
            exit();
        }
    }

    // Sanitize inputs
    $type = sanitizeInput($_POST['type']);
    $capacity = intval($_POST['capacity']);
    $status = sanitizeInput($_POST['status']);

    // Validate capacity
    if ($capacity < 1 || $capacity > 10) {
        $_SESSION['error'] = "Please enter a valid capacity (1-10)";
        header("Location: add_room.php");
        exit();
    }

    // Prepare and execute SQL
    $sql = "INSERT INTO Room (Type, Capacity, AvailabilityStatus) 
            VALUES (?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: add_room.php");
        exit();
    }

    $stmt->bind_param("sis", $type, $capacity, $status);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Room added successfully!";
        header("Location: view_rooms.php");
        exit();
    } else {
        $_SESSION['error'] = "Error adding room: " . $stmt->error;
        header("Location: add_room.php");
        exit();
    }
}

// If not POST request, redirect
header("Location: add_room.php");
exit();
?>
<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Room ID not provided";
    header("Location: view_rooms.php");
    exit();
}

$roomId = intval($_GET['id']);

// Fetch room data
$sql = "SELECT * FROM Room WHERE RoomID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $roomId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Room not found";
    header("Location: view_rooms.php");
    exit();
}

$room = $result->fetch_assoc();

$pageTitle = "Edit Room: " . $room['Type'];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-edit me-2"></i>Edit Room</h3>
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form id="roomForm" action="update_room.php" method="post" class="needs-validation" novalidate>
            <input type="hidden" name="room_id" value="<?php echo $roomId; ?>">
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="type" class="form-label">Room Type *</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="">Select Type</option>
                        <option value="ICU" <?php echo ($room['Type'] == 'ICU') ? 'selected' : ''; ?>>ICU</option>
                        <option value="General" <?php echo ($room['Type'] == 'General') ? 'selected' : ''; ?>>General</option>
                        <option value="Private" <?php echo ($room['Type'] == 'Private') ? 'selected' : ''; ?>>Private</option>
                    </select>
                    <div class="invalid-feedback">Please select room type</div>
                </div>
                <div class="col-md-3">
                    <label for="capacity" class="form-label">Capacity *</label>
                    <input type="number" class="form-control" id="capacity" name="capacity" min="1" max="10" required
                           value="<?php echo htmlspecialchars($room['Capacity']); ?>">
                    <div class="invalid-feedback">Please enter a valid capacity (1-10)</div>
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status *</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="">Select Status</option>
                        <option value="Available" <?php echo ($room['AvailabilityStatus'] == 'Available') ? 'selected' : ''; ?>>Available</option>
                        <option value="Occupied" <?php echo ($room['AvailabilityStatus'] == 'Occupied') ? 'selected' : ''; ?>>Occupied</option>
                        <option value="Maintenance" <?php echo ($room['AvailabilityStatus'] == 'Maintenance') ? 'selected' : ''; ?>>Maintenance</option>
                    </select>
                    <div class="invalid-feedback">Please select status</div>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_rooms.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Update Room
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
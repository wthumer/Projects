<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Room Search Results";
$actionButtons = '<a href="add_room.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Add Room
                 </a>';

$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-search me-2"></i>Search Results</h3>
        <?php echo $actionButtons; ?>
    </div>
    <div class="card-body">
        <!-- Search Form -->
        <div class="mb-3">
            <form action="search_room.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by room type or ID..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_rooms.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Capacity</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($searchTerm)) {
                        if (is_numeric($searchTerm)) {
                            $sql = "SELECT * FROM Room WHERE RoomID = ?";
                            $stmt = $conn->prepare($sql);
                            $roomID = (int)$searchTerm;
                            $stmt->bind_param("i", $roomID);
                        } else {
                            $sql = "SELECT * FROM Room WHERE Type LIKE ?";
                            $stmt = $conn->prepare($sql);
                            $typeSearch = "%{$searchTerm}%";
                            $stmt->bind_param("s", $typeSearch);
                        }
                        
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['RoomID']}</td>
                                    <td>{$row['Type']}</td>
                                    <td>{$row['Capacity']}</td>
                                    <td>{$row['AvailabilityStatus']}</td>
                                    <td>
                                        <a href='edit_room.php?id={$row['RoomID']}' class='btn btn-sm btn-warning'>
                                            <i class='fas fa-edit'></i>
                                        </a>
                                        <a href='delete_room.php?id={$row['RoomID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this room?\")'>
                                            <i class='fas fa-trash'></i>
                                        </a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>No rooms found matching your search criteria</td></tr>";
                        }
                        
                        $stmt->close();
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>Please enter a room type or ID to search</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this room?");
}
</script>

<?php require_once '../includes/footer.php'; ?>
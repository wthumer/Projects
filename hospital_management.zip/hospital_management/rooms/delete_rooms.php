<?php
require_once '../includes/config.php';
session_start();

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Room ID is required for deletion.";
    header("Location: view_rooms.php");
    exit();
}

$roomID = (int)$_GET['id'];

// Check if room exists
$sql = "SELECT * FROM Room WHERE RoomID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $roomID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Room not found.";
    header("Location: view_rooms.php");
    exit();
}

// Delete the room
$deleteSql = "DELETE FROM Room WHERE RoomID = ?";
$deleteStmt = $conn->prepare($deleteSql);
$deleteStmt->bind_param("i", $roomID);

if ($deleteStmt->execute()) {
    $_SESSION['success'] = "Room deleted successfully.";
} else {
    $_SESSION['error'] = "Error deleting room: " . $conn->error;
}

$deleteStmt->close();
$stmt->close();
header("Location: view_rooms.php");
exit();
?>s
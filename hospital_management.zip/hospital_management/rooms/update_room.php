<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['room_id', 'type', 'capacity', 'status'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: edit_room.php?id=" . $_POST['room_id']);
            exit();
        }
    }

    // Sanitize inputs
    $roomId = intval($_POST['room_id']);
    $type = sanitizeInput($_POST['type']);
    $capacity = intval($_POST['capacity']);
    $status = sanitizeInput($_POST['status']);

    // Validate capacity
    if ($capacity < 1 || $capacity > 10) {
        $_SESSION['error'] = "Please enter a valid capacity (1-10)";
        header("Location: edit_room.php?id=" . $roomId);
        exit();
    }

    // Prepare and execute SQL update
    $sql = "UPDATE Room SET 
            Type = ?, 
            Capacity = ?, 
            AvailabilityStatus = ? 
            WHERE RoomID = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: edit_room.php?id=" . $roomId);
        exit();
    }

    $stmt->bind_param("sisi", $type, $capacity, $status, $roomId);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Room updated successfully!";
        header("Location: view_rooms.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating room: " . $stmt->error;
        header("Location: edit_room.php?id=" . $roomId);
        exit();
    }
}

// If not POST request, redirect
header("Location: view_rooms.php");
exit();
?>
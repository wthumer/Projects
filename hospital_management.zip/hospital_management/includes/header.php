<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SUN Medical System - <?php echo $pageTitle ?? ''; ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand mx-auto" href="../index.php">
                <i class="fas fa-hospital me-2"></i>SUN Medical System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="d-flex ms-auto">
                    <span class="navbar-text text-white me-3">
                        <i class="fas fa-user-circle me-1"></i> Admin
                    </span>
                    <a href="../includes/logout.php" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 d-none d-md-block sidebar">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_patients.php' ? 'active' : ''; ?>" href="/hospital_management/patients/view_patients.php">
                                <i class="fas fa-user-injured me-1"></i> Patients
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_staff.php' ? 'active' : ''; ?>" href="/hospital_management/staff/view_staff.php">
                                <i class="fas fa-user-md me-1"></i> Medical Staff
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_departments.php' ? 'active' : ''; ?>" href="/hospital_management/departments/view_departments.php">
                                <i class="fas fa-building me-1"></i> Departments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_rooms.php' ? 'active' : ''; ?>" href="/hospital_management/rooms/view_rooms.php">
                                <i class="fas fa-bed me-1"></i> Rooms
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_appointments.php' ? 'active' : ''; ?>" href="/hospital_management/appointments/view_appointments.php">
                                <i class="fas fa-calendar-check me-1"></i> Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_admissions.php' ? 'active' : ''; ?>" href="/hospital_management/admission/view_admissions.php"\">
                                <i class="fas fa-procedures me-1"></i> Admissions
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_records.php' ? 'active' : ''; ?>" href="/hospital_management/medical_records/view_records.php">
                                <i class="fas fa-file-medical me-1"></i> Medical Records
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'view_bills.php' ? 'active' : ''; ?>" href="/hospital_management/billing/view_bills.php">
                                <i class="fas fa-file-invoice-dollar me-1"></i> Billing
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main Content Area -->
            <div class="col-md-10 ms-sm-auto px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?php echo $pageTitle ?? ''; ?></h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <?php if(isset($actionButtons)) echo $actionButtons; ?>
                    </div>
                </div>
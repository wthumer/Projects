<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);



$host = 'localhost';
$user = 'root';
$password = '';
$database = 'hospital_db';

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input data
function sanitizeInput($data) {
    global $conn;
    return htmlspecialchars(stripslashes(trim($conn->real_escape_string($data))));
}

// Function to display error messages
function displayError($message) {
    return '<div class="alert alert-danger">' . $message . '</div>';
}

// Function to display success messages
function displaySuccess($message) {
    return '<div class="alert alert-success">' . $message . '</div>';
}
?>
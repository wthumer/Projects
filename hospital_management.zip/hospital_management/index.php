<?php
// Load configuration
$configFile = __DIR__ . '/includes/config.php';
if (!file_exists($configFile)) {
    die("Configuration file missing. Please ensure config.php exists in the includes directory.");
}

require_once $configFile;

// Set the page title
$pageTitle = "Dashboard Overview";

// Initialize statistics array
$stats = [
    'patients' => 0,
    'appointments' => 0,
    'unpaid_bills' => 0,
    'departments' => 0,
    'rooms' => 0,
    'staff' => 0,
    'admitted' => 0
];

// Fetch data if connection exists
if ($conn) {
    try {
        // Total Patients
        $result = $conn->query("SELECT COUNT(*) as total FROM Patient");
        if ($result) $stats['patients'] = $result->fetch_assoc()['total'];
        
        // Total Appointments
        $result = $conn->query("SELECT COUNT(*) as total FROM Appointment");
        if ($result) $stats['appointments'] = $result->fetch_assoc()['total'];
        
        // Unpaid Bills
        $result = $conn->query("SELECT COUNT(*) as total FROM billing WHERE PaymentStatus = 'unpaid'");
        if ($result) $stats['unpaid_bills'] = $result->fetch_assoc()['total'];
        
        // Departments
        $result = $conn->query("SELECT COUNT(*) as total FROM department");
        if ($result) $stats['departments'] = $result->fetch_assoc()['total'];
        
        // Rooms
        $result = $conn->query("SELECT COUNT(*) as total FROM room WHERE AvailabilityStatus = 'Available'");
        if ($result) $stats['rooms'] = $result->fetch_assoc()['total'];
        
        // Staff
        $result = $conn->query("SELECT COUNT(*) as total FROM staff");
        if ($result) $stats['staff'] = $result->fetch_assoc()['total'];
        
        // Admitted Patients
        $result = $conn->query("SELECT COUNT(*) as total FROM Admission WHERE Status = 'Admitted'");
        if ($result) $stats['admitted'] = $result->fetch_assoc()['total'];
    } catch (Exception $e) {
        error_log("Database query error: " . $e->getMessage());
    }
}

// Include header
require_once __DIR__ . '/includes/header.php';
?>

<!-- DASHBOARD SPECIFIC CSS -->
<style>
/* ===== Dashboard Container & Layout ===== */
.dashboard-container {
    max-width: 1800px;
    margin: 0 auto;
    padding: 20px;
}

.dashboard-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding: 0 10px;
}

.dashboard-title {
    font-size: 2.2rem;
    font-weight: 700;
    color: #2c3e50;
    margin: 0;
}

.dashboard-date {
    font-size: 1.1rem;
    color: #7f8c8d;
    background: #f8f9fa;
    padding: 8px 15px;
    border-radius: 20px;
    display: flex;
    align-items: center;
}

/* ===== Card Grid System ===== */
.summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 25px;
    margin-top: 20px;
}

.summary-card {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.07);
    overflow: hidden;
    transition: all 0.3s ease;
    border: 1px solid #eef2f7;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.summary-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 20px rgba(0, 0, 0, 0.12);
    border-color: #dbe5f1;
}

/* ===== Card Content Styling ===== */
.card-content {
    padding: 25px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.card-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
}

.card-icon {
    width: 65px;
    height: 65px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 18px;
    font-size: 1.8rem;
    flex-shrink: 0;
}

/* Preserve your existing color classes */
.card-icon.pink { background-color: #fce4ec; color: #ec407a; }
.card-icon.primary { background-color: #e3f2fd; color: #2196f3; }
.card-icon.danger { background-color: #ffebee; color: #f44336; }
.card-icon.info { background-color: #e0f7fa; color: #00bcd4; }
.card-icon.success { background-color: #e8f5e9; color: #4caf50; }
.card-icon.warning { background-color: #fff8e1; color: #ffc107; }
.card-icon.purple { background-color: #f3e5f5; color: #9c27b0; }

.card-label {
    font-size: 1.1rem;
    color: #7f8c8d;
    font-weight: 500;
    margin-bottom: 5px;
}

.card-value {
    font-size: 2.3rem;
    font-weight: 700;
    color: #2c3e50;
    line-height: 1.2;
}

.card-footer {
    margin-top: auto;
    padding-top: 18px;
    border-top: 1px solid #f0f4f8;
}

.card-link {
    display: flex;
    align-items: center;
    color: #3498db;
    font-weight: 500;
    text-decoration: none;
    transition: color 0.2s;
    font-size: 0.95rem;
}

.card-link:hover {
    color: #2980b9;
    text-decoration: underline;
}

.card-link i {
    margin-left: 8px;
    font-size: 0.8rem;
    transition: transform 0.3s;
}

.card-link:hover i {
    transform: translateX(3px);
}

/* ===== Alert Styling ===== */
.alert {
    border-radius: 12px;
}

/* ===== Responsive Adjustments ===== */
@media (max-width: 768px) {
    .dashboard-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .dashboard-date {
        margin-top: 12px;
    }
    
    .summary-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .card-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .card-icon {
        margin-right: 0;
        margin-bottom: 15px;
    }
}
</style>

<div class="dashboard-container">
    <?php if (!$conn || $conn->connect_error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Database Connection Error</strong>
            <p class="mb-0">Unable to connect to the database. Please check your configuration.</p>
            <?php if ($conn->connect_error): ?>
                <small class="d-block mt-2">Error: <?php echo htmlspecialchars($conn->connect_error); ?></small>
            <?php endif; ?>
        </div>
    <?php else: ?>
    
    <div class="dashboard-header">
        <h1 class="dashboard-title">Hospital Overview</h1>
        <div class="dashboard-date">
            <i class="far fa-calendar-alt me-2"></i><?php echo date('l, F j, Y'); ?>
        </div>
    </div>
    
    <div class="summary-grid">
        <!-- Patients Card -->
        <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon pink">
                        <i class="fas fa-user-injured"></i>
                    </div>
                    <div>
                        <div class="card-label">Patients</div>
                        <div class="card-value"><?php echo number_format($stats['patients']); ?></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="patients/view_patients.php" class="card-link">
                        View Patients <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Appointments Card -->
        <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon primary">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div>
                        <div class="card-label">Appointments</div>
                        <div class="card-value"><?php echo number_format($stats['appointments']); ?></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="appointments/view_appointments.php" class="card-link">
                        View Appointments <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Unpaid Bills Card -->
        <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon danger">
                        <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                    <div>
                        <div class="card-label">Unpaid Bills</div>
                        <div class="card-value"><?php echo number_format($stats['unpaid_bills']); ?></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="billing/view_bills.php" class="card-link">
                        View Bills <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Departments Card -->
        <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon info">
                        <i class="fas fa-clinic-medical"></i>
                    </div>
                    <div>
                        <div class="card-label">Departments</div>
                        <div class="card-value"><?php echo number_format($stats['departments']); ?></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="departments/view_departments.php" class="card-link">
                        View Departments <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Rooms Card -->
        <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon success">
                        <i class="fas fa-procedures"></i>
                    </div>
                    <div>
                        <div class="card-label">Available Rooms</div>
                        <div class="card-value"><?php echo number_format($stats['rooms']); ?></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="rooms/view_rooms.php" class="card-link">
                        View Rooms <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Staff Card -->
        <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon warning">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <div>
                        <div class="card-label">Medical Staff</div>
                        <div class="card-value"><?php echo number_format($stats['staff']); ?></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="staff/view_staff.php" class="card-link">
                        View Staff <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Admitted Patients Card -->
        <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon purple">
                        <i class="fas fa-hospital-user"></i>
                    </div>
                    <div>
                        <div class="card-label">Admitted Patients</div>
                        <div class="card-value"><?php echo number_format($stats['admitted']); ?></div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="admission/view_admissions.php" class="card-link">
                        View Admissions <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Emergency Cases Card -->
        <!-- <div class="summary-card">
            <div class="card-content">
                <div class="card-header">
                    <div class="card-icon" style="background-color: #ffebee; color: #f44336;">
                        <i class="fas fa-ambulance"></i>
                    </div>
                    <div>
                        <div class="card-label">Emergency Cases</div>
                        <div class="card-value">0</div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="emergency/view_cases.php" class="card-link">
                        View Cases <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div> -->
    </div>
    <?php endif; ?>
</div>

<?php
// Include footer
require_once __DIR__ . '/includes/footer.php';
?>
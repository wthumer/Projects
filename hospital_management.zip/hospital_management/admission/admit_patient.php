<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Check permissions if needed
// checkAuth();
// checkPermission('admit_patient');

// Get patients and available rooms
$patients = [];
$rooms = [];

try {
    $patients = $conn->query("SELECT PatientID, Name FROM Patient ORDER BY Name");
    $rooms = $conn->query("SELECT RoomID, Type, Capacity FROM Room WHERE AvailabilityStatus = 'Available' ORDER BY Type");
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['error'] = "Error loading required data. Please try again.";
}

$pageTitle = "Admit New Patient";
?>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3 class="card-title"><i class="fas fa-procedures me-2"></i>Admit Patient</h3>
        </div>
        <div class="card-body">
            <?php
            // Display success/error messages
            if (isset($_SESSION['success'])) {
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        ' . $_SESSION['success'] . '
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['error'])) {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        ' . $_SESSION['error'] . '
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>';
                unset($_SESSION['error']);
            }
            ?>
            
            <form id="admissionForm" action="process_admission.php" method="post" class="needs-validation" novalidate>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="patient" class="form-label">Patient *</label>
                        <select class="form-select" id="patient" name="patient" required>
                            <option value="">Select Patient</option>
                            <?php while($patient = $patients->fetch_assoc()): ?>
                                <option value="<?= $patient['PatientID'] ?>">
                                    <?= htmlspecialchars($patient['Name']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <div class="invalid-feedback">Please select a patient</div>
                    </div>
                    <div class="col-md-6">
                        <label for="room" class="form-label">Room *</label>
                        <select class="form-select" id="room" name="room" required>
                            <option value="">Select Room</option>
                            <?php while($room = $rooms->fetch_assoc()): ?>
                                <option value="<?= $room['RoomID'] ?>">
                                    <?= htmlspecialchars($room['Type']) ?> (Capacity: <?= $room['Capacity'] ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <div class="invalid-feedback">Please select a room</div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="diagnosis" class="form-label">Diagnosis *</label>
                    <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required></textarea>
                    <div class="invalid-feedback">Please enter diagnosis</div>
                </div>
                
                <div class="d-flex justify-content-end gap-2">
                    <a href="view_admissions.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Cancel
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Admit Patient
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Client-side form validation
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('admissionForm');
    
    form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }
        form.classList.add('was-validated');
    }, false);
});<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Check permissions if needed
// checkAuth();
// checkPermission('admit_patient');

// Get patients and available rooms
$patients = [];
$rooms = [];

try {
    $patients = $conn->query("SELECT PatientID, Name FROM Patient ORDER BY Name");
    $rooms = $conn->query("SELECT RoomID, Type, Capacity FROM Room WHERE AvailabilityStatus = 'Available' ORDER BY Type");
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    $_SESSION['error'] = "Error loading required data. Please try again.";
}

$pageTitle = "Admit New Patient";
?>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3 class="card-title"><i class="fas fa-procedures me-2"></i>Admit Patient</h3>
        </div>
        <div class="card-body">
            <?php
            // Display success/error messages
            if (isset($_SESSION['success'])) {
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        ' . $_SESSION['success'] . '
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['error'])) {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        ' . $_SESSION['error'] . '
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>';
                unset($_SESSION['error']);
            }
            ?>
            
            <form id="admissionForm" action="process_admission.php" method="post" class="needs-validation" novalidate>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="patient" class="form-label">Patient *</label>
                        <select class="form-select" id="patient" name="patient" required>
                            <option value="">Select Patient</option>
                            <?php while($patient = $patients->fetch_assoc()): ?>
                                <option value="<?= $patient['PatientID'] ?>">
                                    <?= htmlspecialchars($patient['Name']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <div class="invalid-feedback">Please select a patient</div>
                    </div>
                    <div class="col-md-6">
                        <label for="room" class="form-label">Room *</label>
                        <select class="form-select" id="room" name="room" required>
                            <option value="">Select Room</option>
                            <?php while($room = $rooms->fetch_assoc()): ?>
                                <option value="<?= $room['RoomID'] ?>">
                                    <?= htmlspecialchars($room['Type']) ?> (Capacity: <?= $room['Capacity'] ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <div class="invalid-feedback">Please select a room</div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="diagnosis" class="form-label">Diagnosis *</label>
                    <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required></textarea>
                    <div class="invalid-feedback">Please enter diagnosis</div>
                </div>
                
                <div class="d-flex justify-content-end gap-2">
                    <a href="view_admissions.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Cancel
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Admit Patient
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Client-side form validation
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('admissionForm');
    
    form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }
        form.classList.add('was-validated');
    }, false);
});
</script>

<?php require_once '../includes/footer.php'; ?>
</script>

<?php require_once '../includes/footer.php'; ?>
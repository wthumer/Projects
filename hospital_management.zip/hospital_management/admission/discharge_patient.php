<?php
require_once '../includes/config.php';

// Validate admission ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Admission ID is required for discharge.";
    header("Location: view_admissions.php");
    exit();
}

$admissionID = (int)$_GET['id'];

// Verify active admission exists
$checkSql = "SELECT a.RoomID 
             FROM Admission a 
             WHERE a.AdmissionID = ? AND a.Status = 'Admitted'";
$checkStmt = $conn->prepare($checkSql);
$checkStmt->bind_param("i", $admissionID);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows === 0) {
    $_SESSION['error'] = "Active admission not found or already discharged.";
    header("Location: view_admissions.php");
    exit();
}

$admission = $checkResult->fetch_assoc();
$roomID = $admission['RoomID'];

// Process discharge
$conn->begin_transaction();

try {
    // Update admission status
    $dischargeSql = "UPDATE Admission 
                    SET Status = 'Discharged', 
                        DischargeDate = NOW() 
                    WHERE AdmissionID = ?";
    $dischargeStmt = $conn->prepare($dischargeSql);
    $dischargeStmt->bind_param("i", $admissionID);
    
    if (!$dischargeStmt->execute()) {
        throw new Exception("Failed to update admission status");
    }
    
    // Free up the room
    $roomSql = "UPDATE Room 
               SET AvailabilityStatus = 'Available' 
               WHERE RoomID = ?";
    $roomStmt = $conn->prepare($roomSql);
    $roomStmt->bind_param("i", $roomID);
    
    if (!$roomStmt->execute()) {
        throw new Exception("Failed to update room status");
    }
    
    $conn->commit();
    $_SESSION['success'] = "Patient #$admissionID discharged successfully.";
    header("Location: view_admissions.php");
    exit();
    
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = "Discharge failed: " . $e->getMessage();
    header("Location: view_admissions.php");
    exit();
}
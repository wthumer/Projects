<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Admission Search Results";
$actionButton = '<a href="admit_patient.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> New Admission
                 </a>';

// Get search term and status filter
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'Admitted';

?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-search me-2"></i>Search Results</h3>
        <?php echo $actionButton; ?>
    </div>
    <div class="card-body">
        <!-- Search Form -->
        <div class="mb-3">
            <form action="search_admission.php" method="GET" class="row g-3">
                <div class="col-md-5">
                    <input type="text" name="search" class="form-control" placeholder="Search by patient name or admission ID..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="Admitted" <?= $statusFilter == 'Admitted' ? 'selected' : '' ?>>Admitted</option>
                        <option value="Discharged" <?= $statusFilter == 'Discharged' ? 'selected' : '' ?>>Discharged</option>
                        <option value="All" <?= $statusFilter == 'All' ? 'selected' : '' ?>>All</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_admissions.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Room</th>
                        <th>Admission Date</th>
                        <th>Discharge Date</th>
                        <th>Status</th>
                        <th>Diagnosis</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($searchTerm)) {
                        // Prepare SQL to search by Patient Name or AdmissionID with status filter
                        $sql = "SELECT a.AdmissionID, a.Diagnosis, a.AdmissionDate, a.DischargeDate, a.Status,
                               p.Name AS PatientName, r.Type AS RoomType
                               FROM Admission a
                               JOIN Patient p ON a.PatientID = p.PatientID
                               JOIN Room r ON a.RoomID = r.RoomID
                               WHERE (p.Name LIKE ? OR a.AdmissionID = ?)";
                        
                        if ($statusFilter != 'All') {
                            $sql .= " AND a.Status = ?";
                        }
                        
                        $stmt = $conn->prepare($sql);
                        
                        if (is_numeric($searchTerm)) {
                            $admissionID = (int)$searchTerm;
                            $nameSearch = "%{$searchTerm}%";
                            
                            if ($statusFilter != 'All') {
                                $stmt->bind_param("sis", $nameSearch, $admissionID, $statusFilter);
                            } else {
                                $stmt->bind_param("si", $nameSearch, $admissionID);
                            }
                        } else {
                            $nameSearch = "%{$searchTerm}%";
                            $admissionID = 0;
                            
                            if ($statusFilter != 'All') {
                                $stmt->bind_param("sis", $nameSearch, $admissionID, $statusFilter);
                            } else {
                                $stmt->bind_param("si", $nameSearch, $admissionID);
                            }
                        }
                        
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $statusBadge = $row['Status'] == 'Admitted' ? 
                                    '<span class="badge bg-success">Admitted</span>' : 
                                    '<span class="badge bg-secondary">Discharged</span>';
                                
                                echo "<tr>
                                    <td>{$row['AdmissionID']}</td>
                                    <td>" . htmlspecialchars($row['PatientName']) . "</td>
                                    <td>" . htmlspecialchars($row['RoomType']) . "</td>
                                    <td>" . date('M d, Y h:i A', strtotime($row['AdmissionDate'])) . "</td>
                                    <td>" . ($row['DischargeDate'] ? date('M d, Y h:i A', strtotime($row['DischargeDate'])) : 'N/A') . "</td>
                                    <td>{$statusBadge}</td>
                                    <td>" . htmlspecialchars($row['Diagnosis']) . "</td>
                                    <td>";
                                
                                if ($row['Status'] == 'Admitted') {
                                    echo "<div class='btn-group' role='group'>
                                        <a href='edit_admission.php?id={$row['AdmissionID']}' class='btn btn-sm btn-warning'>
                                            <i class='fas fa-edit'></i>
                                        </a>
                                        <a href='discharge_patient.php?id={$row['AdmissionID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to discharge this patient?\");'>
                                            <i class='fas fa-sign-out-alt'></i>
                                        </a>
                                    </div>";
                                } else {
                                    echo "<span class='text-muted'>No actions</span>";
                                }
                                
                                echo "</td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8' class='text-center'>No admissions found matching your search criteria</td></tr>";
                        }
                        
                        $stmt->close();
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>Please enter a patient name or admission ID to search</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
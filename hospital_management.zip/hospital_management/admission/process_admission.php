<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: admit_patient.php");
    exit();
}

// Validate required fields
$required = ['patient', 'room', 'diagnosis'];
$errors = [];

foreach ($required as $field) {
    if (empty($_POST[$field])) {
        $errors[] = ucfirst($field) . " is required";
    }
}

if (!empty($errors)) {
    $_SESSION['error'] = implode("<br>", $errors);
    header("Location: admit_patient.php");
    exit();
}

// Sanitize inputs
$patientID = (int)$_POST['patient'];
$roomID = (int)$_POST['room'];
$diagnosis = sanitizeInput($_POST['diagnosis']);

// Start transaction
$conn->begin_transaction();

try {
    // 1. Check if room is still available
    $roomCheck = $conn->prepare("SELECT AvailabilityStatus FROM Room WHERE RoomID = ? FOR UPDATE");
    $roomCheck->bind_param("i", $roomID);
    $roomCheck->execute();
    $roomResult = $roomCheck->get_result();
    
    if ($roomResult->num_rows === 0) {
        throw new Exception("Selected room not found");
    }
    
    $roomStatus = $roomResult->fetch_assoc();
    if ($roomStatus['AvailabilityStatus'] !== 'Available') {
        throw new Exception("Selected room is no longer available");
    }
    
    // 2. Admit patient
    $admitStmt = $conn->prepare("INSERT INTO Admission (PatientID, RoomID, Diagnosis, AdmissionDate, Status) VALUES (?, ?, ?, NOW(), 'Admitted')");
    $admitStmt->bind_param("iis", $patientID, $roomID, $diagnosis);
    
    if (!$admitStmt->execute()) {
        throw new Exception("Failed to admit patient");
    }
    
    // 3. Update room status
    $roomUpdate = $conn->prepare("UPDATE Room SET AvailabilityStatus = 'Occupied' WHERE RoomID = ?");
    $roomUpdate->bind_param("i", $roomID);
    
    if (!$roomUpdate->execute()) {
        throw new Exception("Failed to update room status");
    }
    
    // Commit transaction
    $conn->commit();
    
    $_SESSION['success'] = "Patient admitted successfully!";
    header("Location: view_admissions.php");
    exit();
    
} catch (Exception $e) {
    $conn->rollback();
    error_log("Admission Error: " . $e->getMessage());
    $_SESSION['error'] = "Error admitting patient: " . $e->getMessage();
    header("Location: admit_patient.php");
    exit();
}
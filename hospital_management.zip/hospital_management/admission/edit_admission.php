<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Check if admission ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Admission ID not provided";
    header("Location: view_admissions.php");
    exit();
}

$admissionId = intval($_GET['id']);

// Fetch admission data
$sql = "SELECT a.*, p.Name AS PatientName, r.Type AS RoomType 
        FROM Admission a
        JOIN Patient p ON a.PatientID = p.PatientID
        JOIN Room r ON a.RoomID = r.RoomID
        WHERE a.AdmissionID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admissionId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Admission not found";
    header("Location: view_admissions.php");
    exit();
}

$admission = $result->fetch_assoc();

// Get available rooms (include currently assigned room even if not available)
$rooms = $conn->query("SELECT RoomID, Type FROM Room WHERE AvailabilityStatus = 'Available' OR RoomID = " . $admission['RoomID'] . " ORDER BY Type");

$pageTitle = "Edit Admission: " . $admission['PatientName'];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-edit me-2"></i>Edit Admission</h3>
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form id="admissionForm" action="update_admission.php" method="post" class="needs-validation" novalidate>
            <input type="hidden" name="admission_id" value="<?php echo $admissionId; ?>">
            
            <div class="mb-3">
                <label class="form-label">Patient</label>
                <input type="text" class="form-control" value="<?php echo htmlspecialchars($admission['PatientName']); ?>" readonly>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Status</label>
                <input type="text" class="form-control" value="<?php echo $admission['Status'] == 'Admitted' ? 'Admitted' : 'Discharged on ' . date('M d, Y h:i A', strtotime($admission['DischargeDate'])); ?>" readonly>
            </div>
            
            <div class="mb-3">
                <label for="room" class="form-label">Room *</label>
                <select class="form-select" id="room" name="room" required <?php echo $admission['Status'] == 'Discharged' ? 'disabled' : ''; ?>>
                    <option value="">Select Room</option>
                    <?php while($room = $rooms->fetch_assoc()): ?>
                        <option value="<?= $room['RoomID'] ?>" <?= ($room['RoomID'] == $admission['RoomID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($room['Type']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <div class="invalid-feedback">Please select a room</div>
            </div>
            
            <div class="mb-3">
                <label for="diagnosis" class="form-label">Diagnosis *</label>
                <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required><?php 
                    echo htmlspecialchars($admission['Diagnosis']); 
                ?></textarea>
                <div class="invalid-feedback">Please enter diagnosis</div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_admissions.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <?php if ($admission['Status'] == 'Admitted'): ?>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Update Admission
                    </button>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
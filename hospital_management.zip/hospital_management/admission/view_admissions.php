<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Patient Admissions";
$actionButton = '<a href="admit_patient.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> New Admission
                </a>';

// Get filter status
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'Admitted';

// Display messages
if (isset($_SESSION['success'])) {
    echo displaySuccess($_SESSION['success']);
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    echo displayError($_SESSION['error']);
    unset($_SESSION['error']);
}
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-procedures me-2"></i><?= $pageTitle ?></h3>
        <?= $actionButton ?>
    </div>
    <div class="card-body">
        <!-- Filter and Search Form -->
        <div class="row mb-4">
            <div class="col-md-4">
                <form method="GET" class="row g-3">
                    <div class="col-md-8">
                        <select name="status" class="form-select" onchange="this.form.submit()">
                            <option value="Admitted" <?= $statusFilter == 'Admitted' ? 'selected' : '' ?>>Admitted Patients</option>
                            <option value="Discharged" <?= $statusFilter == 'Discharged' ? 'selected' : '' ?>>Discharged Patients</option>
                            <option value="All" <?= $statusFilter == 'All' ? 'selected' : '' ?>>All Patients</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <a href="view_admissions.php" class="btn btn-secondary w-100">
                            <i class="fas fa-sync"></i> Reset
                        </a>
                    </div>
                </form>
            </div>
            <div class="col-md-8">
                <form method="GET" action="search_admission.php" class="row g-3">
                    <div class="col-md-8">
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search patients..." required>
                        <input type="hidden" name="status" value="<?= $statusFilter ?>">
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Admissions Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Room</th>
                        <th>Admitted On</th>
                        <th>Discharged On</th>
                        <th>Status</th>
                        <th>Diagnosis</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT a.AdmissionID, a.Diagnosis, a.AdmissionDate, a.DischargeDate, a.Status,
                           p.Name AS PatientName, r.Type AS RoomType
                           FROM Admission a
                           JOIN Patient p ON a.PatientID = p.PatientID
                           JOIN Room r ON a.RoomID = r.RoomID";
                    
                    // Add status filter
                    if ($statusFilter != 'All') {
                        $sql .= " WHERE a.Status = ?";
                    }
                    
                    $sql .= " ORDER BY a.AdmissionDate DESC";
                    
                    $stmt = $conn->prepare($sql);
                    
                    if ($statusFilter != 'All') {
                        $stmt->bind_param("s", $statusFilter);
                    }
                    
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $statusBadge = $row['Status'] == 'Admitted' ? 
                                '<span class="badge bg-success">Admitted</span>' : 
                                '<span class="badge bg-secondary">Discharged</span>';
                            
                            echo '<tr>
                                <td>'.$row['AdmissionID'].'</td>
                                <td>'.htmlspecialchars($row['PatientName']).'</td>
                                <td>'.htmlspecialchars($row['RoomType']).'</td>
                                <td>'.date('M j, Y g:i A', strtotime($row['AdmissionDate'])).'</td>
                                <td>'.($row['DischargeDate'] ? date('M j, Y g:i A', strtotime($row['DischargeDate'])) : 'N/A').'</td>
                                <td>'.$statusBadge.'</td>
                                <td>'.htmlspecialchars($row['Diagnosis']).'</td>
                                <td>
                                    <div class="btn-group" role="group">';
                                    
                            if ($row['Status'] == 'Admitted') {
                                echo '<a href="edit_admission.php?id='.$row['AdmissionID'].'" 
                                       class="btn btn-sm btn-warning me-1">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="discharge_patient.php?id='.$row['AdmissionID'].'" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm(\'Discharge this patient?\')">
                                        <i class="fas fa-sign-out-alt"></i>
                                    </a>';
                            } else {
                                echo '<span class="text-muted">No actions</span>';
                            }
                                    
                            echo '</div>
                                </td>
                            </tr>';
                        }
                    } else {
                        echo '<tr><td colspan="8" class="text-center">No admissions found</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: view_admissions.php");
    exit();
}

// Validate required fields
$required = ['admission_id', 'room', 'diagnosis'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        $_SESSION['error'] = "Please fill in all required fields";
        header("Location: edit_admission.php?id=" . $_POST['admission_id']);
        exit();
    }
}

// Sanitize inputs
$admissionId = intval($_POST['admission_id']);
$roomId = intval($_POST['room']);
$diagnosis = sanitizeInput($_POST['diagnosis']);

// Start transaction
$conn->begin_transaction();

try {
    // 1. Get current admission details
    $currentSql = "SELECT RoomID, Status FROM Admission WHERE AdmissionID = ?";
    $currentStmt = $conn->prepare($currentSql);
    $currentStmt->bind_param("i", $admissionId);
    $currentStmt->execute();
    $currentResult = $currentStmt->get_result();
    
    if ($currentResult->num_rows === 0) {
        throw new Exception("Admission not found");
    }
    
    $currentAdmission = $currentResult->fetch_assoc();
    $currentRoomId = $currentAdmission['RoomID'];
    $currentStatus = $currentAdmission['Status'];
    
    // Can't update discharged admissions
    if ($currentStatus == 'Discharged') {
        throw new Exception("Cannot update a discharged admission");
    }
    
    // 2. Update admission
    $updateSql = "UPDATE Admission SET 
                 RoomID = ?, 
                 Diagnosis = ? 
                 WHERE AdmissionID = ?";
    
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("isi", $roomId, $diagnosis, $admissionId);
    
    if (!$updateStmt->execute()) {
        throw new Exception("Failed to update admission");
    }
    
    // 3. Update room statuses if room changed
    if ($currentRoomId != $roomId) {
        // Free up old room
        $freeRoomSql = "UPDATE Room SET AvailabilityStatus = 'Available' WHERE RoomID = ?";
        $freeRoomStmt = $conn->prepare($freeRoomSql);
        $freeRoomStmt->bind_param("i", $currentRoomId);
        
        if (!$freeRoomStmt->execute()) {
            throw new Exception("Failed to free up previous room");
        }
        
        // Occupy new room
        $occupyRoomSql = "UPDATE Room SET AvailabilityStatus = 'Occupied' WHERE RoomID = ?";
        $occupyRoomStmt = $conn->prepare($occupyRoomSql);
        $occupyRoomStmt->bind_param("i", $roomId);
        
        if (!$occupyRoomStmt->execute()) {
            throw new Exception("Failed to occupy new room");
        }
    }
    
    // Commit transaction
    $conn->commit();
    
    $_SESSION['success'] = "Admission updated successfully!";
    header("Location: view_admissions.php");
    exit();
    
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = "Error updating admission: " . $e->getMessage();
    header("Location: edit_admission.php?id=" . $admissionId);
    exit();
}
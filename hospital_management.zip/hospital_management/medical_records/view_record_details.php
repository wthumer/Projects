<?php
require_once '../includes/config.php';

// Check if record ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Record ID not provided";
    header("Location: view_records.php");
    exit();
}

$recordId = intval($_GET['id']);

// Fetch record data with patient information
$sql = "SELECT m.*, p.Name AS PatientName 
        FROM MedicalRecord m
        JOIN Patient p ON m.PatientID = p.PatientID
        WHERE m.RecordID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recordId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Record not found";
    header("Location: view_records.php");
    exit();
}

$record = $result->fetch_assoc();

$pageTitle = "Medical Record Details";
require_once '../includes/header.php';

// Handle messages
if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
    unset($_SESSION['error']);
}

if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
    unset($_SESSION['success']);
}
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">
            <i class="fas fa-file-medical me-2"></i>Medical Record Details
        </h3>
        <div>
            <a href="edit_record.php?id=<?= $record['RecordID'] ?>" class="btn btn-warning me-1">
                <i class="fas fa-edit me-1"></i> Edit
            </a>
            <a href="view_records.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Back to Records
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-6">
                <h4>Patient Information</h4>
                <table class="table table-bordered">
                    <tr>
                        <th width="30%">Patient Name</th>
                        <td><?= htmlspecialchars($record['PatientName']) ?></td>
                    </tr>
                    <tr>
                        <th>Record ID</th>
                        <td><?= $record['RecordID'] ?></td>
                    </tr>
                    <tr>
                        <th>Record Date</th>
                        <td><?= date('M j, Y', strtotime($record['Date'])) ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="mb-4">
            <h4>Symptoms</h4>
            <div class="p-3 bg-light rounded">
                <?= nl2br(htmlspecialchars($record['Symptoms'])) ?>
            </div>
        </div>

        <div class="mb-4">
            <h4>Diagnosis</h4>
            <div class="p-3 bg-light rounded">
                <?= nl2br(htmlspecialchars($record['Diagnosis'])) ?>
            </div>
        </div>

        <div class="mb-4">
            <h4>Treatment</h4>
            <div class="p-3 bg-light rounded">
                <?= nl2br(htmlspecialchars($record['Treatment'])) ?>
            </div>
        </div>

        <?php if (!empty($record['Prescriptions'])): ?>
        <div class="mb-4">
            <h4>Prescriptions</h4>
            <div class="p-3 bg-light rounded">
                <?= nl2br(htmlspecialchars($record['Prescriptions'])) ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($record['Result'])): ?>
        <div class="mb-4">
            <h4>Result</h4>
            <div class="p-3 bg-light rounded">
                <?= nl2br(htmlspecialchars($record['Result'])) ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
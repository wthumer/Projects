<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['patient', 'symptoms', 'diagnosis', 'treatment'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: add_record.php");
            exit();
        }
    }

    // Sanitize inputs
    $patient = intval($_POST['patient']);
    $symptoms = sanitizeInput($_POST['symptoms']);
    $diagnosis = sanitizeInput($_POST['diagnosis']);
    $treatment = sanitizeInput($_POST['treatment']);
    $prescriptions = sanitizeInput($_POST['prescriptions'] ?? '');
    $result = sanitizeInput($_POST['result'] ?? '');

    // Prepare and execute SQL
    $sql = "INSERT INTO MedicalRecord (PatientID, Symptoms, Diagnosis, Treatment, Prescriptions, Result) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: add_record.php");
        exit();
    }

    $stmt->bind_param("isssss", $patient, $symptoms, $diagnosis, $treatment, $prescriptions, $result);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Medical record added successfully!";
        header("Location: view_records.php");
        exit();
    } else {
        $_SESSION['error'] = "Error adding medical record: " . $stmt->error;
        header("Location: add_record.php");
        exit();
    }
}

// If not POST request, redirect
header("Location: add_record.php");
exit();
?>
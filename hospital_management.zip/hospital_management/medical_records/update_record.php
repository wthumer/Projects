<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['record_id', 'patient', 'symptoms', 'diagnosis', 'treatment'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: edit_record.php?id=" . $_POST['record_id']);
            exit();
        }
    }

    // Sanitize inputs
    $recordId = intval($_POST['record_id']);
    $patient = intval($_POST['patient']);
    $symptoms = sanitizeInput($_POST['symptoms']);
    $diagnosis = sanitizeInput($_POST['diagnosis']);
    $treatment = sanitizeInput($_POST['treatment']);
    $prescriptions = sanitizeInput($_POST['prescriptions'] ?? '');
    $result = sanitizeInput($_POST['result'] ?? '');

    // Prepare and execute SQL
    $sql = "UPDATE MedicalRecord SET 
            PatientID = ?, 
            Symptoms = ?, 
            Diagnosis = ?, 
            Treatment = ?, 
            Prescriptions = ?, 
            Result = ? 
            WHERE RecordID = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: edit_record.php?id=" . $recordId);
        exit();
    }

    $stmt->bind_param("isssssi", $patient, $symptoms, $diagnosis, $treatment, $prescriptions, $result, $recordId);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Medical record updated successfully!";
        header("Location: view_records.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating medical record: " . $stmt->error;
        header("Location: edit_record.php?id=" . $recordId);
        exit();
    }
}

// If not POST request, redirect
header("Location: view_records.php");
exit();
?>
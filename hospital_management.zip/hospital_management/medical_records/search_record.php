<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Medical Record Search Results";
$actionButtons = '<a href="add_record.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Add Record
                 </a>';

// Get search term
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-search me-2"></i>Search Results</h3>
        <?= $actionButtons ?>
    </div>
    <div class="card-body">
        <!-- Search Form -->
        <div class="mb-3">
            <form action="search_record.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by patient name, diagnosis or record ID..." value="<?= htmlspecialchars($searchTerm) ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_records.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Date</th>
                        <th>Diagnosis</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($searchTerm)) {
                        // Prepare SQL to search by patient name, diagnosis or record ID
                        $sql = "SELECT m.*, p.Name AS PatientName 
                                FROM MedicalRecord m
                                JOIN Patient p ON m.PatientID = p.PatientID
                                WHERE p.Name LIKE ? OR 
                                      m.Diagnosis LIKE ? OR 
                                      m.RecordID = ?";
                        
                        $stmt = $conn->prepare($sql);
                        
                        if (is_numeric($searchTerm)) {
                            $recordID = (int)$searchTerm;
                            $searchPattern = "%{$searchTerm}%";
                            $stmt->bind_param("ssi", $searchPattern, $searchPattern, $recordID);
                        } else {
                            $searchPattern = "%{$searchTerm}%";
                            $recordID = 0; // Will never match since RecordID is positive
                            $stmt->bind_param("ssi", $searchPattern, $searchPattern, $recordID);
                        }
                        
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['RecordID']}</td>
                                    <td>{$row['PatientName']}</td>
                                    <td>" . date('M j, Y', strtotime($row['Date'])) . "</td>
                                    <td>" . htmlspecialchars($row['Diagnosis']) . "</td>
                                    <td>
                                        <a href='edit_record.php?id={$row['RecordID']}' class='btn btn-sm btn-warning'>
                                            <i class='fas fa-edit'></i>
                                        </a>
                                        <a href='delete_record.php?id={$row['RecordID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this record?\")'>
                                            <i class='fas fa-trash'></i>
                                        </a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>No records found matching your search criteria</td></tr>";
                        }
                        
                        $stmt->close();
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>Please enter a patient name, diagnosis or record ID to search</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this record?");
}
</script>

<?php require_once '../includes/footer.php'; ?>
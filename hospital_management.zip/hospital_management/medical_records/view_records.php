<?php
require_once '../includes/config.php';

$pageTitle = "";
require_once '../includes/header.php';

// Handle messages
if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
    unset($_SESSION['error']);
}

if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success">' . $_SESSION['success'] . '</div>';
    unset($_SESSION['success']);
}
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-file-medical me-2"></i>Medical Records</h3>
        <div>
            <a href="add_record.php" class="btn btn-primary me-2">
                <i class="fas fa-plus me-1"></i> Add Record
            </a>
            <a href="search_record.php" class="btn btn-info">
                <i class="fas fa-search me-1"></i> Search
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Date</th>
                        <th>Diagnosis</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT m.*, p.Name AS PatientName 
                            FROM MedicalRecord m
                            JOIN Patient p ON m.PatientID = p.PatientID
                            ORDER BY m.Date DESC";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['RecordID']}</td>
                                <td>{$row['PatientName']}</td>
                                <td>" . date('M j, Y', strtotime($row['Date'])) . "</td>
                                <td>" . htmlspecialchars($row['Diagnosis']) . "</td>
                                <td>
                                    <a href='view_record_details.php?id={$row['RecordID']}' class='btn btn-sm btn-info me-1'>
                                        <i class='fas fa-eye'></i>
                                    </a>
                                    <a href='edit_record.php?id={$row['RecordID']}' class='btn btn-sm btn-warning me-1'>
                                        <i class='fas fa-edit'></i>
                                    </a>
                                    <a href='delete_record.php?id={$row['RecordID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this record?\")'>
                                        <i class='fas fa-trash'></i>
                                    </a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
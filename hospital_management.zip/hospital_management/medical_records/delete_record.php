<?php
require_once '../includes/config.php';

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Record ID is required for deletion.";
    header("Location: view_records.php");
    exit();
}

$recordID = (int)$_GET['id'];

// Check if record exists
$sql = "SELECT * FROM MedicalRecord WHERE RecordID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recordID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Record not found.";
    header("Location: view_records.php");
    exit();
}

// Delete the record
$deleteSql = "DELETE FROM MedicalRecord WHERE RecordID = ?";
$deleteStmt = $conn->prepare($deleteSql);
$deleteStmt->bind_param("i", $recordID);

if ($deleteStmt->execute()) {
    $_SESSION['success'] = "Record deleted successfully.";
} else {
    $_SESSION['error'] = "Error deleting record: " . $conn->error;
}

$deleteStmt->close();
$stmt->close();
header("Location: view_records.php");
exit();
?>
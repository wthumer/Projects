<?php
require_once '../includes/config.php';

$pageTitle = "Add Medical Record";
require_once '../includes/header.php';
?>

<div class="card">
    <div class="card-header">
       
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form id="recordForm" action="process_record.php" method="post" class="needs-validation" novalidate>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="patient" class="form-label">Patient *</label>
                    <select class="form-select" id="patient" name="patient" required>
                        <option value="">-- Select Patient --</option>
                        <?php 
                        $patients = $conn->query("SELECT * FROM Patient ORDER BY Name");
                        while($patient = $patients->fetch_assoc()): ?>
                            <option value="<?= $patient['PatientID'] ?>" <?= isset($_POST['patient']) && $_POST['patient'] == $patient['PatientID'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($patient['Name']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                    <div class="invalid-feedback">Please select a patient</div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="symptoms" class="form-label">Symptoms *</label>
                <textarea class="form-control" id="symptoms" name="symptoms" rows="3" required><?= isset($_POST['symptoms']) ? htmlspecialchars($_POST['symptoms']) : '' ?></textarea>
                <div class="invalid-feedback">Please enter symptoms</div>
            </div>
            
            <div class="mb-3">
                <label for="diagnosis" class="form-label">Diagnosis *</label>
                <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required><?= isset($_POST['diagnosis']) ? htmlspecialchars($_POST['diagnosis']) : '' ?></textarea>
                <div class="invalid-feedback">Please enter diagnosis</div>
            </div>
            
            <div class="mb-3">
                <label for="treatment" class="form-label">Treatment *</label>
                <textarea class="form-control" id="treatment" name="treatment" rows="3" required><?= isset($_POST['treatment']) ? htmlspecialchars($_POST['treatment']) : '' ?></textarea>
                <div class="invalid-feedback">Please enter treatment</div>
            </div>
            
            <div class="mb-3">
                <label for="prescriptions" class="form-label">Prescriptions</label>
                <textarea class="form-control" id="prescriptions" name="prescriptions" rows="3"><?= isset($_POST['prescriptions']) ? htmlspecialchars($_POST['prescriptions']) : '' ?></textarea>
            </div>
            
            <div class="mb-3">
                <label for="result" class="form-label">Result</label>
                <textarea class="form-control" id="result" name="result" rows="3"><?= isset($_POST['result']) ? htmlspecialchars($_POST['result']) : '' ?></textarea>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_records.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Record
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
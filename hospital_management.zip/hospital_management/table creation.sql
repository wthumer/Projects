-- Patients Table
CREATE TABLE patients (
    PatientID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Age INT NULL,
    Gender NVARCHAR(10) CHECK (Gender IN ('Male', 'Female', 'Other')) NULL,
    Address NTEXT NULL,
    Contact NVARCHAR(20) NULL
);

-- Departments Table
CREATE TABLE departments (
    DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NTEXT NULL,
    HOD NVARCHAR(100) NULL
);

-- Staff Table (Doctors, Nurses, etc.)
CREATE TABLE staff (
    StaffID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Role NVARCHAR(20) CHECK (Role IN ('Doctor', 'Nurse', 'Admin', 'Technician')) NOT NULL,
    Specialization NVARCHAR(100) NULL,
    Contact NVARCHAR(20) NULL,
    AvailabilitySchedule TIME NULL,
    Shift NVARCHAR(20) NOT NULL,
    DepartmentID INT NULL,
    FOREIGN KEY (DepartmentID) REFERENCES departments(DepartmentID) ON DELETE SET NULL
);

-- Rooms Table
CREATE TABLE rooms (
    RoomID INT IDENTITY(1,1) PRIMARY KEY,
    Type NVARCHAR(10) CHECK (Type IN ('ICU', 'General', 'Private')) NOT NULL,
    Capacity INT NULL,
    AvailabilityStatus NVARCHAR(15) CHECK (AvailabilityStatus IN ('Available', 'Occupied', 'Maintenance')) DEFAULT 'Available'
);

-- Appointments Table
CREATE TABLE appointments (
    AppointmentID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT NULL,
    DoctorID INT NULL,
    Date DATE NOT NULL,
    Time TIME NOT NULL,
    Reason NTEXT NULL,
    Status NVARCHAR(15) CHECK (Status IN ('Scheduled', 'Completed', 'Cancelled')) DEFAULT 'Scheduled',
    FOREIGN KEY (PatientID) REFERENCES patients(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (DoctorID) REFERENCES staff(StaffID) ON DELETE SET NULL
);

-- Admissions Table
CREATE TABLE admissions (
    AdmissionID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT NULL,
    RoomID INT NULL,
    AdmissionDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    Diagnosis NTEXT NULL,
    Status NVARCHAR(15) CHECK (Status IN ('Admitted', 'Discharged')) NOT NULL DEFAULT 'Admitted',
    DischargeDate DATETIME NULL,
    FOREIGN KEY (PatientID) REFERENCES patients(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (RoomID) REFERENCES rooms(RoomID) ON DELETE SET NULL
);

-- Medical Records Table
CREATE TABLE medical_records (
    RecordID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT NULL,
    Date DATETIME DEFAULT CURRENT_TIMESTAMP,
    Symptoms NTEXT NULL,
    Diagnosis NTEXT NULL,
    Treatment NTEXT NULL,
    Prescriptions NTEXT NULL,
    Result NTEXT NULL,
    FOREIGN KEY (PatientID) REFERENCES patients(PatientID) ON DELETE CASCADE
);

-- Billing Table
CREATE TABLE billing (
    BillID INT IDENTITY(1,1) PRIMARY KEY,
    PatientID INT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    PaymentStatus NVARCHAR(10) CHECK (PaymentStatus IN ('Paid', 'Unpaid', 'Partial')) DEFAULT 'Unpaid',
    Date DATE NOT NULL,
    PaymentMethod NVARCHAR(20) CHECK (PaymentMethod IN ('Cash', 'Credit Card', 'Insurance', 'Online Payment')) NULL,
    FOREIGN KEY (PatientID) REFERENCES patients(PatientID) ON DELETE CASCADE
);
<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Patient Search";
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-search me-2"></i>Patient Search</h3>
        <div>
            <a href="add_patient.php" class="btn btn-primary me-2">
                <i class="fas fa-plus me-1"></i> Add Patient
            </a>
            <a href="view_patients.php" class="btn btn-secondary">
                <i class="fas fa-list me-1"></i> View All
            </a>
        </div>
    </div>
    <div class="card-body">
        <!-- Search Form -->
        <div class="mb-4">
            <form action="search_patient.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by patient name or ID..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($searchTerm)) {
                        // ... [keep the existing PHP search code] ...
                        // Just update the action buttons to match:
                        echo "<td>
                            <a href='view_patient_details.php?id={$row['PatientID']}' class='btn btn-sm btn-info me-1'>
                                <i class='fas fa-eye'></i>
                            </a>
                            <a href='edit_patient.php?id={$row['PatientID']}' class='btn btn-sm btn-warning me-1'>
                                <i class='fas fa-edit'></i>
                            </a>
                            <a href='delete_patient.php?id={$row['PatientID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this patient?\")'>
                                <i class='fas fa-trash'></i>
                            </a>
                        </td>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
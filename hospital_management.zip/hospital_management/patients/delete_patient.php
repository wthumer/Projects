<?php
require_once '../includes/config.php';
session_start();

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Patient ID is required for deletion.";
    header("Location: view_patients.php");
    exit();
}

$patientID = (int)$_GET['id'];

// Check if patient exists
$sql = "SELECT * FROM Patient WHERE PatientID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patientID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Patient not found.";
    header("Location: view_patients.php");
    exit();
}

// Delete the patient
$deleteSql = "DELETE FROM Patient WHERE PatientID = ?";
$deleteStmt = $conn->prepare($deleteSql);
$deleteStmt->bind_param("i", $patientID);

if ($deleteStmt->execute()) {
    $_SESSION['success'] = "Patient deleted successfully.";
} else {
    $_SESSION['error'] = "Error deleting patient: " . $conn->error;
}

$deleteStmt->close();
$stmt->close();
header("Location: view_patients.php");
exit();
?>
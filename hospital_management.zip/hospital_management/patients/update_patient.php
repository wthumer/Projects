<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['patient_id', 'name', 'age', 'gender', 'address', 'contact'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: edit_patient.php?id=" . $_POST['patient_id']);
            exit();
        }
    }

    // Sanitize inputs
    $patientId = intval($_POST['patient_id']);
    $name = sanitizeInput($_POST['name']);
    $age = intval($_POST['age']);
    $gender = sanitizeInput($_POST['gender']);
    $address = sanitizeInput($_POST['address']);
    $contact = sanitizeInput($_POST['contact']);

    // Validate age
    if ($age < 0 || $age > 120) {
        $_SESSION['error'] = "Please enter a valid age (0-120)";
        header("Location: edit_patient.php?id=" . $patientId);
        exit();
    }

    // Validate contact number
    if (!preg_match('/^[0-9]{10,15}$/', $contact)) {
        $_SESSION['error'] = "Please enter a valid contact number (10-15 digits)";
        header("Location: edit_patient.php?id=" . $patientId);
        exit();
    }
    // Add this before the UPDATE statement
    $checkSql = "SELECT PatientID FROM Patient WHERE Contact = ? AND PatientID != ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("si", $contact, $patientId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    $_SESSION['error'] = "Another patient with this contact number already exists";
    header("Location: edit_patient.php?id=" . $patientId);
    exit();
}
    // Prepare and execute SQL update
    $sql = "UPDATE Patient SET 
            Name = ?, 
            Age = ?, 
            Gender = ?, 
            Address = ?, 
            Contact = ? 
            WHERE PatientID = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: edit_patient.php?id=" . $patientId);
        exit();
    }

    $stmt->bind_param("sisssi", $name, $age, $gender, $address, $contact, $patientId);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Patient updated successfully!";
        header("Location: view_patients.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating patient: " . $stmt->error;
        header("Location: edit_patient.php?id=" . $patientId);
        exit();
    }
}

// If not POST request, redirect
header("Location: view_patients.php");
exit();
?>
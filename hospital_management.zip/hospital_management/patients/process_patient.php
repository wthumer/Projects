<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['name', 'age', 'gender', 'address', 'contact'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: add_patient.php");
            exit();
        }
    }

    // Sanitize inputs
    $name = sanitizeInput($_POST['name']);
    $age = intval($_POST['age']);
    $gender = sanitizeInput($_POST['gender']);
    $address = sanitizeInput($_POST['address']);
    $contact = sanitizeInput($_POST['contact']);

    // Validate age
    if ($age < 0 || $age > 120) {
        $_SESSION['error'] = "Please enter a valid age (0-120)";
        header("Location: add_patient.php");
        exit();
    }

    // Validate contact number
    if (!preg_match('/^[0-9]{10,15}$/', $contact)) {
        $_SESSION['error'] = "Please enter a valid contact number (10-15 digits)";
        header("Location: add_patient.php");
        exit();
    }
 // Add this before the INSERT statement
     $checkSql = "SELECT PatientID FROM Patient WHERE Contact = ?";
    $checkStmt = $conn->prepare($checkSql);
$checkStmt->bind_param("s", $contact);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    $_SESSION['error'] = "A patient with this contact number already exists";
    header("Location: add_patient.php");
    exit();
}
    // Prepare and execute SQL (without email)
    $sql = "INSERT INTO Patient (Name, Age, Gender, Address, Contact) 
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: add_patient.php");
        exit();
    }

    $stmt->bind_param("sisss", $name, $age, $gender, $address, $contact);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Patient added successfully!";
        header("Location: view_patients.php");
        exit();
    } else {
        $_SESSION['error'] = "Error adding patient: " . $stmt->error;
        header("Location: add_patient.php");
        exit();
    }
}

// If not POST request, redirect
header("Location: add_patient.php");
exit();
?>
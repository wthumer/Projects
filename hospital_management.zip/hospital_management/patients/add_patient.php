<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Add New Patient";
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-user-plus me-2"></i>Add New Patient</h3>
    </div>
    <div class="card-body">
        <?php
        // Display error messages if they exist
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form id="patientForm" action="process_patient.php" method="post" class="needs-validation" novalidate>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Full Name *</label>
                    <input type="text" class="form-control" id="name" name="name" required
                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                    <div class="invalid-feedback">Please enter patient's name</div>
                </div>
                <div class="col-md-3">
                    <label for="age" class="form-label">Age *</label>
                    <input type="number" class="form-control" id="age" name="age" min="0" max="120" required
                           value="<?php echo isset($_POST['age']) ? htmlspecialchars($_POST['age']) : ''; ?>">
                    <div class="invalid-feedback">Please enter a valid age (0-120)</div>
                </div>
                <div class="col-md-3">
                    <label for="gender" class="form-label">Gender *</label>
                    <select class="form-select" id="gender" name="gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                        <option value="Other" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                    </select>
                    <div class="invalid-feedback">Please select gender</div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="address" class="form-label">Address *</label>
                <textarea class="form-control" id="address" name="address" rows="3" required><?php 
                    echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; 
                ?></textarea>
                <div class="invalid-feedback">Please enter address</div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="contact" class="form-label">Contact Number *</label>
                    <input type="tel" class="form-control" id="contact" name="contact" 
                           pattern="[0-9]{10,15}" required
                           value="<?php echo isset($_POST['contact']) ? htmlspecialchars($_POST['contact']) : ''; ?>">
                    <div class="invalid-feedback">Please enter a valid contact number (10-15 digits)</div>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_patients.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Patient
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
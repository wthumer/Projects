<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Check if patient ID is provided
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Patient ID not provided";
    header("Location: view_patients.php");
    exit();
}

$patientId = intval($_GET['id']);

// Fetch patient data
$sql = "SELECT * FROM Patient WHERE PatientID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patientId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Patient not found";
    header("Location: view_patients.php");
    exit();
}

$patient = $result->fetch_assoc();

$pageTitle = "Edit Patient: " . $patient['Name'];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-user-edit me-2"></i>Edit Patient</h3>
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form id="patientForm" action="update_patient.php" method="post" class="needs-validation" novalidate>
            <input type="hidden" name="patient_id" value="<?php echo $patientId; ?>">
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Full Name *</label>
                    <input type="text" class="form-control" id="name" name="name" required
                           value="<?php echo htmlspecialchars($patient['Name']); ?>">
                    <div class="invalid-feedback">Please enter patient's name</div>
                </div>
                <div class="col-md-3">
                    <label for="age" class="form-label">Age *</label>
                    <input type="number" class="form-control" id="age" name="age" min="0" max="120" required
                           value="<?php echo htmlspecialchars($patient['Age']); ?>">
                    <div class="invalid-feedback">Please enter a valid age (0-120)</div>
                </div>
                <div class="col-md-3">
                    <label for="gender" class="form-label">Gender *</label>
                    <select class="form-select" id="gender" name="gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male" <?php echo ($patient['Gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo ($patient['Gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                        <option value="Other" <?php echo ($patient['Gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                    </select>
                    <div class="invalid-feedback">Please select gender</div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="address" class="form-label">Address *</label>
                <textarea class="form-control" id="address" name="address" rows="3" required><?php 
                    echo htmlspecialchars($patient['Address']); 
                ?></textarea>
                <div class="invalid-feedback">Please enter address</div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="contact" class="form-label">Contact Number *</label>
                    <input type="tel" class="form-control" id="contact" name="contact" 
                           pattern="[0-9]{10,15}" required
                           value="<?php echo htmlspecialchars($patient['Contact']); ?>">
                    <div class="invalid-feedback">Please enter a valid contact number (10-15 digits)</div>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_patients.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Update Patient
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Get patients
$patients = $conn->query("SELECT * FROM Patient ORDER BY Name");

$pageTitle = "Create New Bill";
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-file-invoice-dollar me-2"></i>Create New Bill</h3>
    </div>
    <div class="card-body">
        <?php
        if (isset($_SESSION['error'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
            unset($_SESSION['error']);
        }
        ?>
        
        <form action="process_bill.php" method="post" class="needs-validation" novalidate>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="patient" class="form-label">Patient *</label>
                    <select class="form-select" id="patient" name="patient" required>
                        <option value="">-- Select Patient --</option>
                        <?php while($patient = $patients->fetch_assoc()): ?>
                            <option value="<?= $patient['PatientID'] ?>"><?= htmlspecialchars($patient['Name']) ?></option>
                        <?php endwhile; ?>
                    </select>
                    <div class="invalid-feedback">Please select a patient</div>
                </div>
                <div class="col-md-6">
                    <label for="amount" class="form-label">Amount *</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0" required>
                    </div>
                    <div class="invalid-feedback">Please enter a valid amount</div>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="status" class="form-label">Payment Status *</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="Unpaid" selected>Unpaid</option>
                        <option value="Paid">Paid</option>
                        <option value="Partial">Partial</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="method" class="form-label">Payment Method</label>
                    <select class="form-select" id="method" name="method">
                        <option value="">-- Select Method --</option>
                        <option value="Cash">Cash</option>
                        <option value="Credit Card">Credit Card</option>
                        <option value="Insurance">Insurance</option>
                        <option value="Online Payment">Online Payment</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="date" class="form-label">Date *</label>
                    <input type="date" class="form-control" id="date" name="date" required value="<?= date('Y-m-d') ?>">
                    <div class="invalid-feedback">Please select a date</div>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_bills.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Create Bill
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Form validation
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
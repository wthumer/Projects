<?php
require_once '../includes/config.php';
session_start();

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Bill ID is required.";
    header("Location: view_bills.php");
    exit();
}

$billID = (int)$_GET['id'];

// Check if bill exists and is unpaid
$sql = "SELECT * FROM Billing WHERE BillID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $billID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Bill not found.";
    header("Location: view_bills.php");
    exit();
}

$bill = $result->fetch_assoc();

if ($bill['PaymentStatus'] != 'Unpaid') {
    $_SESSION['error'] = "Only unpaid bills can be marked as paid.";
    header("Location: view_bills.php");
    exit();
}

// Update the bill to paid status
$updateSql = "UPDATE Billing SET PaymentStatus = 'Paid' WHERE BillID = ?";
$updateStmt = $conn->prepare($updateSql);
$updateStmt->bind_param("i", $billID);

if ($updateStmt->execute()) {
    $_SESSION['success'] = "Bill #{$billID} has been marked as paid.";
} else {
    $_SESSION['error'] = "Error updating bill: " . $conn->error;
}

$updateStmt->close();
$stmt->close();
header("Location: view_bills.php");
exit();
?>
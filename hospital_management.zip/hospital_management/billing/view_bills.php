<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Get filter parameters
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';

$pageTitle = "Billing Records";
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2><i class="fas fa-file-invoice-dollar me-2"></i><?php echo $pageTitle; ?></h2>
                <a href="create_bill.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Create Bill
                </a>
            </div>
        </div>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-6">
                    <input type="text" name="search" class="form-control" placeholder="Search patient, bill ID, or amount..." 
                           value="<?php echo htmlspecialchars($searchTerm); ?>">
                </div>
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">All Statuses</option>
                        <option value="Paid" <?= $status_filter == 'Paid' ? 'selected' : '' ?>>Paid</option>
                        <option value="Unpaid" <?= $status_filter == 'Unpaid' ? 'selected' : '' ?>>Unpaid</option>
                        <option value="Partial" <?= $status_filter == 'Partial' ? 'selected' : '' ?>>Partial</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Bill ID</th>
                            <th>Patient</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Payment Method</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT b.*, p.Name AS PatientName 
                                FROM Billing b
                                JOIN Patient p ON b.PatientID = p.PatientID";
                        
                        $conditions = [];
                        $params = [];
                        $types = '';
                        
                        if (!empty($status_filter)) {
                            $conditions[] = "b.PaymentStatus = ?";
                            $params[] = $status_filter;
                            $types .= 's';
                        }
                        
                        if (!empty($searchTerm)) {
                            if (is_numeric($searchTerm)) {
                                $conditions[] = "(b.BillID = ? OR p.PatientID = ? OR b.Amount = ?)";
                                $params[] = (int)$searchTerm;
                                $params[] = (int)$searchTerm;
                                $params[] = (float)$searchTerm;
                                $types .= 'iid';
                            } else {
                                $conditions[] = "p.Name LIKE ?";
                                $params[] = "%$searchTerm%";
                                $types .= 's';
                            }
                        }
                        
                        if (!empty($conditions)) {
                            $sql .= " WHERE " . implode(" AND ", $conditions);
                        }
                        
                        $sql .= " ORDER BY b.Date DESC";
                        
                        $stmt = $conn->prepare($sql);
                        if ($stmt) {
                            if (!empty($params)) {
                                $stmt->bind_param($types, ...$params);
                            }
                            $stmt->execute();
                            $result = $stmt->get_result();
                        } else {
                            $result = $conn->query($sql);
                        }
                        
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $status_class = strtolower($row['PaymentStatus']);
                                echo "<tr>
                                    <td>#{$row['BillID']}</td>
                                    <td>{$row['PatientName']}</td>
                                    <td>$" . number_format($row['Amount'], 2) . "</td>
                                    <td><span class='badge bg-" . ($status_class == 'paid' ? 'success' : ($status_class == 'unpaid' ? 'danger' : 'warning')) . "'>{$row['PaymentStatus']}</span></td>
                                    <td>" . date('m/d/Y', strtotime($row['Date'])) . "</td>
                                    <td>{$row['PaymentMethod']}</td>
                                    <td>
                                        <div class='btn-group' role='group'>";
                                
                                // Edit button
                                echo "<a href='edit_bill.php?id={$row['BillID']}' class='btn btn-sm btn-warning' title='Edit'>
                                        <i class='fas fa-edit'></i>
                                    </a>";
                                
                                // Mark as Paid button (only for unpaid bills)
                                if ($row['PaymentStatus'] == 'Unpaid') {
                                    echo "<a href='mark_paid.php?id={$row['BillID']}' class='btn btn-sm btn-success' title='Mark as Paid'
                                         onclick='return confirm(\"Mark bill #{$row['BillID']} as paid?\")'>
                                        <i class='fas fa-check'></i>
                                    </a>";
                                }
                                
                                // Delete button
                                echo "<a href='delete_bill.php?id={$row['BillID']}' class='btn btn-sm btn-danger' title='Delete'
                                     onclick='return confirm(\"Delete bill #{$row['BillID']}?\")'>
                                    <i class='fas fa-trash'></i>
                                </a>";
                                
                                echo "</div></td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center py-4'>No bills found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
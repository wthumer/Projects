<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['bill_id', 'patient', 'amount', 'status', 'date'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: edit_bill.php?id=" . $_POST['bill_id']);
            exit();
        }
    }

    // Sanitize inputs
    $billId = intval($_POST['bill_id']);
    $patientId = intval($_POST['patient']);
    $amount = floatval($_POST['amount']);
    $status = sanitizeInput($_POST['status']);
    $method = isset($_POST['method']) ? sanitizeInput($_POST['method']) : '';
    $date = sanitizeInput($_POST['date']);

    // Validate amount
    if ($amount <= 0) {
        $_SESSION['error'] = "Please enter a valid amount";
        header("Location: edit_bill.php?id=" . $billId);
        exit();
    }

    // Prepare and execute SQL update
    $sql = "UPDATE Billing SET 
            PatientID = ?, 
            Amount = ?, 
            PaymentStatus = ?, 
            PaymentMethod = ?, 
            Date = ? 
            WHERE BillID = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: edit_bill.php?id=" . $billId);
        exit();
    }

    $stmt->bind_param("idsssi", $patientId, $amount, $status, $method, $date, $billId);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Bill updated successfully!";
        header("Location: view_bills.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating bill: " . $stmt->error;
        header("Location: edit_bill.php?id=" . $billId);
        exit();
    }
}

// If not POST request, redirect
header("Location: view_bills.php");
exit();
?>
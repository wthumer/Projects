<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

// Get search parameters
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

$pageTitle = "Bill Search Results";
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2><i class="fas fa-search me-2"></i><?php echo $pageTitle; ?></h2>
                <a href="create_bill.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Create Bill
                </a>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="get" action="search_bills.php" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by patient name, bill ID, or amount..." 
                           value="<?php echo htmlspecialchars($searchTerm); ?>" required>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_bills.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Bill ID</th>
                            <th>Patient</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Payment Method</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (!empty($searchTerm)) {
                            $sql = "SELECT b.*, p.Name AS PatientName 
                                    FROM Billing b
                                    JOIN Patient p ON b.PatientID = p.PatientID
                                    WHERE (p.Name LIKE ? OR b.BillID = ? OR b.Amount = ?)";
                            
                            if (!empty($status_filter)) {
                                $sql .= " AND b.PaymentStatus = ?";
                            }
                            
                            $sql .= " ORDER BY b.Date DESC";
                            
                            $stmt = $conn->prepare($sql);
                            if ($stmt) {
                                if (is_numeric($searchTerm)) {
                                    $searchParam1 = "%$searchTerm%";
                                    $searchParam2 = (int)$searchTerm;
                                    $searchParam3 = (float)$searchTerm;
                                    
                                    if (!empty($status_filter)) {
                                        $stmt->bind_param("sids", $searchParam1, $searchParam2, $searchParam3, $status_filter);
                                    } else {
                                        $stmt->bind_param("sid", $searchParam1, $searchParam2, $searchParam3);
                                    }
                                } else {
                                    $searchParam = "%$searchTerm%";
                                    
                                    if (!empty($status_filter)) {
                                        $stmt->bind_param("sids", $searchParam, 0, 0, $status_filter);
                                    } else {
                                        $stmt->bind_param("s", $searchParam);
                                    }
                                }
                                
                                $stmt->execute();
                                $result = $stmt->get_result();
                                
                                if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                        $status_class = strtolower($row['PaymentStatus']);
                                        echo "<tr>
                                            <td>#{$row['BillID']}</td>
                                            <td>{$row['PatientName']}</td>
                                            <td>$" . number_format($row['Amount'], 2) . "</td>
                                            <td><span class='badge bg-" . ($status_class == 'paid' ? 'success' : ($status_class == 'unpaid' ? 'danger' : 'warning')) . "'>{$row['PaymentStatus']}</span></td>
                                            <td>" . date('m/d/Y', strtotime($row['Date'])) . "</td>
                                            <td>{$row['PaymentMethod']}</td>
                                            <td>
                                                <div class='btn-group' role='group'>
                                                    <a href='edit_bill.php?id={$row['BillID']}' class='btn btn-sm btn-warning' title='Edit'>
                                                        <i class='fas fa-edit'></i>
                                                    </a>
                                                    <a href='mark_paid.php?id={$row['BillID']}' class='btn btn-sm btn-success' title='Mark as Paid'
                                                     onclick='return confirm(\"Mark bill #{$row['BillID']} as paid?\")'>
                                                        <i class='fas fa-check'></i>
                                                    </a>
                                                    <a href='delete_bill.php?id={$row['BillID']}' class='btn btn-sm btn-danger' title='Delete'
                                                     onclick='return confirm(\"Delete bill #{$row['BillID']}?\")'>
                                                        <i class='fas fa-trash'></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='7' class='text-center py-4'>No bills found matching your search</td></tr>";
                                }
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center py-4'>Please enter a search term</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
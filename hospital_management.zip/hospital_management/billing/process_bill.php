<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate required fields
    $required = ['patient', 'amount', 'status', 'date'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            header("Location: create_bill.php");
            exit();
        }
    }

    // Sanitize inputs
    $patient = intval($_POST['patient']);
    $amount = floatval($_POST['amount']);
    $status = sanitizeInput($_POST['status']);
    $method = isset($_POST['method']) ? sanitizeInput($_POST['method']) : '';
    $date = sanitizeInput($_POST['date']);

    // Validate amount
    if ($amount <= 0) {
        $_SESSION['error'] = "Please enter a valid amount";
        header("Location: create_bill.php");
        exit();
    }

    // Prepare and execute SQL
    $sql = "INSERT INTO Billing (PatientID, Amount, PaymentStatus, PaymentMethod, Date) 
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        header("Location: create_bill.php");
        exit();
    }

    $stmt->bind_param("idsss", $patient, $amount, $status, $method, $date);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Bill created successfully!";
        header("Location: view_bills.php");
        exit();
    } else {
        $_SESSION['error'] = "Error creating bill: " . $stmt->error;
        header("Location: create_bill.php");
        exit();
    }
}

// If not POST request, redirect
header("Location: create_bill.php");
exit();
?>
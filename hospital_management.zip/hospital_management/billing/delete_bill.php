<?php
require_once '../includes/config.php';
session_start();

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Bill ID is required for deletion.";
    header("Location: view_bills.php");
    exit();
}

$billID = (int)$_GET['id'];

// Check if bill exists
$sql = "SELECT * FROM Billing WHERE BillID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $billID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Bill not found.";
    header("Location: view_bills.php");
    exit();
}

// Delete the bill
$deleteSql = "DELETE FROM Billing WHERE BillID = ?";
$deleteStmt = $conn->prepare($deleteSql);
$deleteStmt->bind_param("i", $billID);

if ($deleteStmt->execute()) {
    $_SESSION['success'] = "Bill deleted successfully.";
} else {
    $_SESSION['error'] = "Error deleting bill: " . $conn->error;
}

$deleteStmt->close();
$stmt->close();
header("Location: view_bills.php");
exit();
?>
<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Staff ID not provided";
    header("Location: view_staff.php");
    exit();
}

$staffId = intval($_GET['id']);

$sql = "SELECT * FROM Staff WHERE StaffID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $staffId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Staff member not found";
    header("Location: view_staff.php");
    exit();
}

$staff = $result->fetch_assoc();
$departments = $conn->query("SELECT * FROM Department");
$pageTitle = "Edit Staff: " . $staff['Name'];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-user-edit me-2"></i>Edit Staff Member</h3>
    </div>
    <div class="card-body">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <form id="staffForm" action="update_staff.php" method="post" class="needs-validation" novalidate>
            <input type="hidden" name="staff_id" value="<?= $staffId ?>">
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Full Name *</label>
                    <input type="text" class="form-control" id="name" name="name" required
                           value="<?= htmlspecialchars($staff['Name']) ?>">
                    <div class="invalid-feedback">Please enter staff member's name</div>
                </div>
                <div class="col-md-6">
                    <label for="role" class="form-label">Role *</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="">Select Role</option>
                        <option value="Doctor" <?= ($staff['Role'] == 'Doctor') ? 'selected' : '' ?>>Doctor</option>
                        <option value="Nurse" <?= ($staff['Role'] == 'Nurse') ? 'selected' : '' ?>>Nurse</option>
                        <option value="Admin" <?= ($staff['Role'] == 'Admin') ? 'selected' : '' ?>>Admin</option>
                        <option value="Technician" <?= ($staff['Role'] == 'Technician') ? 'selected' : '' ?>>Technician</option>
                    </select>
                    <div class="invalid-feedback">Please select role</div>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="specialization" class="form-label">Specialization</label>
                    <input type="text" class="form-control" id="specialization" name="specialization"
                           value="<?= htmlspecialchars($staff['Specialization']) ?>">
                </div>
                <div class="col-md-6">
                    <label for="contact" class="form-label">Contact Number *</label>
                    <input type="tel" class="form-control" id="contact" name="contact" 
                           pattern="[0-9]{10,15}" required
                           value="<?= htmlspecialchars($staff['Contact']) ?>">
                    <div class="invalid-feedback">Please enter a valid contact number (10-15 digits)</div>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="department" class="form-label">Department</label>
                    <select class="form-select" id="department" name="department">
                        <option value="">-- Select Department --</option>
                        <?php while($dept = $departments->fetch_assoc()): ?>
                            <option value="<?= $dept['DepartmentID'] ?>" <?= ($staff['DepartmentID'] == $dept['DepartmentID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($dept['Name']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="schedule" class="form-label">Availability Schedule (Start Time)</label>
                    <input type="time" class="form-control" id="schedule" name="schedule"
                           value="<?= isset($staff['AvailabilitySchedule']) ? substr($staff['AvailabilitySchedule'], 0, 5) : '' ?>">
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="shift" class="form-label">Shift</label>
                    <select class="form-select" id="shift" name="shift">
                        <option value="">-- Select Shift --</option>
                        <option value="Day Shift" <?= ($staff['Shift'] == 'Day Shift') ? 'selected' : '' ?>>Day Shift</option>
                        <option value="Night Shift" <?= ($staff['Shift'] == 'Night Shift') ? 'selected' : '' ?>>Night Shift</option>
                    </select>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_staff.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Update Staff
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
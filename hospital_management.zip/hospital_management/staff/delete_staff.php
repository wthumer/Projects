<?php
require_once '../includes/config.php';

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Staff ID is required for deletion.";
    header("Location: view_staff.php");
    exit();
}

$staffID = (int)$_GET['id'];

// Check if staff exists
$sql = "SELECT * FROM Staff WHERE StaffID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $staffID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Staff member not found.";
    header("Location: view_staff.php");
    exit();
}

// Delete the staff member
$deleteSql = "DELETE FROM Staff WHERE StaffID = ?";
$deleteStmt = $conn->prepare($deleteSql);
$deleteStmt->bind_param("i", $staffID);

if ($deleteStmt->execute()) {
    $_SESSION['success'] = "Staff member deleted successfully.";
} else {
    $_SESSION['error'] = "Error deleting staff member: " . $conn->error;
}

$deleteStmt->close();
$stmt->close();
header("Location: view_staff.php");
exit();
?>
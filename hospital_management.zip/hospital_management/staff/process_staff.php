<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $required = ['name', 'role', 'contact'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "Please fill in all required fields";
            $_SESSION['form_data'] = $_POST;
            header("Location: add_staff.php");
            exit();
        }
    }

    $name = sanitizeInput($_POST['name']);
    $role = sanitizeInput($_POST['role']);
    $specialization = isset($_POST['specialization']) ? sanitizeInput($_POST['specialization']) : '';
    $contact = sanitizeInput($_POST['contact']);
    $department = isset($_POST['department']) ? intval($_POST['department']) : null;
    $schedule = isset($_POST['schedule']) ? $_POST['schedule'] . ':00' : null;
    $shift = isset($_POST['shift']) ? sanitizeInput($_POST['shift']) : null;

    if (!preg_match('/^[0-9]{10,15}$/', $contact)) {
        $_SESSION['error'] = "Please enter a valid contact number (10-15 digits)";
        $_SESSION['form_data'] = $_POST;
        header("Location: add_staff.php");
        exit();
    }

    try {
        $sql = "INSERT INTO Staff (Name, Role, Specialization, Contact, DepartmentID, AvailabilitySchedule, Shift) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Database error: " . $conn->error);
        }

        $stmt->bind_param("ssssiss", $name, $role, $specialization, $contact, $department, $schedule, $shift);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Staff member added successfully!";
            header("Location: view_staff.php");
            exit();
        } else {
            throw new Exception("Error adding staff member: " . $stmt->error);
        }
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        $_SESSION['form_data'] = $_POST;
        header("Location: add_staff.php");
        exit();
    }
}

header("Location: view_staff.php");
exit();
?>
<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Add New Staff Member";
$departments = $conn->query("SELECT * FROM Department");
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-user-plus me-2"></i>Add New Staff Member</h3>
    </div>
    <div class="card-body">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <form id="staffForm" action="process_staff.php" method="post" class="needs-validation" novalidate>
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Full Name *</label>
                    <input type="text" class="form-control" id="name" name="name" required
                           value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>">
                    <div class="invalid-feedback">Please enter staff member's name</div>
                </div>
                <div class="col-md-6">
                    <label for="role" class="form-label">Role *</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="">Select Role</option>
                        <option value="Doctor" <?= (isset($_POST['role']) && $_POST['role'] == 'Doctor') ? 'selected' : '' ?>>Doctor</option>
                        <option value="Nurse" <?= (isset($_POST['role']) && $_POST['role'] == 'Nurse') ? 'selected' : '' ?>>Nurse</option>
                        <option value="Admin" <?= (isset($_POST['role']) && $_POST['role'] == 'Admin') ? 'selected' : '' ?>>Admin</option>
                        <option value="Technician" <?= (isset($_POST['role']) && $_POST['role'] == 'Technician') ? 'selected' : '' ?>>Technician</option>
                    </select>
                    <div class="invalid-feedback">Please select role</div>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="specialization" class="form-label">Specialization</label>
                    <input type="text" class="form-control" id="specialization" name="specialization"
                           value="<?= isset($_POST['specialization']) ? htmlspecialchars($_POST['specialization']) : '' ?>">
                </div>
                <div class="col-md-6">
                    <label for="contact" class="form-label">Contact Number *</label>
                    <input type="tel" class="form-control" id="contact" name="contact" 
                           pattern="[0-9]{10,15}" required
                           value="<?= isset($_POST['contact']) ? htmlspecialchars($_POST['contact']) : '' ?>">
                    <div class="invalid-feedback">Please enter a valid contact number (10-15 digits)</div>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="department" class="form-label">Department</label>
                    <select class="form-select" id="department" name="department">
                        <option value="">-- Select Department --</option>
                        <?php while($dept = $departments->fetch_assoc()): ?>
                            <option value="<?= $dept['DepartmentID'] ?>" <?= (isset($_POST['department']) && $_POST['department'] == $dept['DepartmentID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($dept['Name']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="schedule" class="form-label">Availability Schedule (Start Time)</label>
                    <input type="time" class="form-control" id="schedule" name="schedule"
                           value="<?= isset($_POST['schedule']) ? htmlspecialchars($_POST['schedule']) : '' ?>">
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="shift" class="form-label">Shift</label>
                    <select class="form-select" id="shift" name="shift">
                        <option value="">-- Select Shift --</option>
                        <option value="Day Shift" <?= (isset($_POST['shift']) && $_POST['shift'] == 'Day Shift') ? 'selected' : '' ?>>Day Shift</option>
                        <option value="Night Shift" <?= (isset($_POST['shift']) && $_POST['shift'] == 'Night Shift') ? 'selected' : '' ?>>Night Shift</option>
                    </select>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="view_staff.php" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left me-1"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Staff
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

<?php require_once '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Validate required fields
        $required = ['staff_id', 'name', 'role', 'contact'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Please fill in all required fields");
            }
        }

        // Sanitize inputs
        $staffId = intval($_POST['staff_id']);
        $name = sanitizeInput($_POST['name']);
        $role = sanitizeInput($_POST['role']);
        $specialization = isset($_POST['specialization']) ? sanitizeInput($_POST['specialization']) : '';
        $contact = sanitizeInput($_POST['contact']);
        $department = isset($_POST['department']) ? intval($_POST['department']) : null;
        $schedule = isset($_POST['schedule']) ? $_POST['schedule'] . ':00' : null;
        $shift = isset($_POST['shift']) ? sanitizeInput($_POST['shift']) : null;

        // Validate contact number
        if (!preg_match('/^[0-9]{10,15}$/', $contact)) {
            throw new Exception("Please enter a valid contact number (10-15 digits)");
        }

        // Check if contact number exists for another staff
        $checkSql = "SELECT StaffID FROM Staff WHERE Contact = ? AND StaffID != ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("si", $contact, $staffId);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult->num_rows > 0) {
            throw new Exception("Another staff member with this contact number already exists");
        }

        // Prepare SQL update
        $sql = "UPDATE Staff SET 
                Name = ?, 
                Role = ?, 
                Specialization = ?, 
                Contact = ?, 
                DepartmentID = ?, 
                AvailabilitySchedule = ?,
                Shift = ?
                WHERE StaffID = ?";
        
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Database error: " . $conn->error);
        }

        $stmt->bind_param("ssssissi", $name, $role, $specialization, $contact, $department, $schedule, $shift, $staffId);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Staff member updated successfully!";
            header("Location: view_staff.php");
            exit();
        } else {
            throw new Exception("Error updating staff member: " . $stmt->error);
        }
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: edit_staff.php?id=" . ($_POST['staff_id'] ?? ''));
        exit();
    }
}

header("Location: view_staff.php");
exit();
?>
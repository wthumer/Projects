<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Staff Search Results";
$actionButtons = '<a href="add_staff.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Add Staff
                 </a>';

$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-search me-2"></i>Search Results</h3>
        <?= $actionButtons ?>
    </div>
    <div class="card-body">
        <div class="mb-3">
            <form action="search_staff.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by staff name or ID..." value="<?= htmlspecialchars($searchTerm) ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_staff.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Specialization</th>
                        <th>Department</th>
                        <th>Shift</th>
                        <th>Start Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($searchTerm)) {
                        $sql = "SELECT s.*, d.Name AS DepartmentName 
                                FROM Staff s 
                                LEFT JOIN Department d ON s.DepartmentID = d.DepartmentID
                                WHERE s.Name LIKE ? OR s.StaffID = ?";
                        
                        $stmt = $conn->prepare($sql);
                        
                        if (is_numeric($searchTerm)) {
                            $staffID = (int)$searchTerm;
                            $nameSearch = "%{$searchTerm}%";
                            $stmt->bind_param("si", $nameSearch, $staffID);
                        } else {
                            $nameSearch = "%{$searchTerm}%";
                            $staffID = 0;
                            $stmt->bind_param("si", $nameSearch, $staffID);
                        }
                        
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $time = $row['AvailabilitySchedule'] ? date('H:i', strtotime($row['AvailabilitySchedule'])) : null;
                                $displayTime = $time ? date('h:i A', strtotime($row['AvailabilitySchedule'])) : '';
                                
                                echo "<tr>
                                    <td>{$row['StaffID']}</td>
                                    <td>{$row['Name']}</td>
                                    <td>{$row['Role']}</td>
                                    <td>{$row['Specialization']}</td>
                                    <td>{$row['DepartmentName']}</td>
                                    <td>{$row['Shift']}</td>
                                    <td>{$displayTime}</td>
                                    <td>
                                        <a href='edit_staff.php?id={$row['StaffID']}' class='btn btn-sm btn-warning'>
                                            <i class='fas fa-edit'></i>
                                        </a>
                                        <a href='delete_staff.php?id={$row['StaffID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this staff member?\")'>
                                            <i class='fas fa-trash'></i>
                                        </a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8' class='text-center'>No staff members found matching your search criteria</td></tr>";
                        }
                        
                        $stmt->close();
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>Please enter a staff name or ID to search</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this staff member?");
}
</script>

<?php require_once '../includes/footer.php'; ?>
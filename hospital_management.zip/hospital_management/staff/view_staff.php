<?php
require_once '../includes/config.php';
require_once '../includes/header.php';

$pageTitle = "Staff Management";
$actionButtons = '<a href="add_staff.php" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> Add Staff
                 </a>';
?>

<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $_SESSION['success'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $_SESSION['error'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-user-md me-2"></i>Staff List</h3>
        <?= $actionButtons ?>
    </div>
    <div class="card-body">
        <div class="mb-3">
            <form action="search_staff.php" method="GET" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="search" class="form-control" placeholder="Search by staff name or ID..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Search
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="view_staff.php" class="btn btn-secondary w-100">
                        <i class="fas fa-sync me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Specialization</th>
                        <th>Department</th>
                        <th>Shift</th>
                        <th>Start Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT s.*, d.Name AS DepartmentName 
                            FROM Staff s 
                            LEFT JOIN Department d ON s.DepartmentID = d.DepartmentID";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $time = $row['AvailabilitySchedule'] ? date('H:i', strtotime($row['AvailabilitySchedule'])) : null;
                            $displayTime = $time ? date('h:i A', strtotime($row['AvailabilitySchedule'])) : '';
                            
                            echo "<tr>
                                <td>{$row['StaffID']}</td>
                                <td>{$row['Name']}</td>
                                <td>{$row['Role']}</td>
                                <td>{$row['Specialization']}</td>
                                <td>{$row['DepartmentName']}</td>
                                <td>{$row['Shift']}</td>
                                <td>{$displayTime}</td>
                                <td>
                                    <a href='edit_staff.php?id={$row['StaffID']}' class='btn btn-sm btn-warning'>
                                        <i class='fas fa-edit'></i>
                                    </a>
                                    <a href='delete_staff.php?id={$row['StaffID']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this staff member?\")'>
                                        <i class='fas fa-trash'></i>
                                    </a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>No staff members found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this staff member?");
}
</script>

<?php require_once '../includes/footer.php'; ?>